import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import L from 'leaflet';
import {
    AlertTriangle,
    BarChart3,
    ChevronDown,
    ChevronUp,
    Crosshair,
    Database,
    Eye,
    EyeOff,
    Filter,
    Flame,
    Layers3,
    LocateFixed,
    MapPin,
    Maximize2,
    Minimize2,
    Minus,
    Plus,
    RefreshCcw,
    Search,
    Shield,
    SlidersHorizontal,
    Table2,
    Target,
    X,
} from 'lucide-react';

import MapView from '@/Components/MapView';
import { incidents as dummyIncidents } from '@/data/dummy';
import { analyzeKDE } from '@/lib/kdeAnalysis';
import { fetchApprovedReportIncidents, type MapIncident } from '@/lib/databaseIncidents';
import type { UserLocation } from '@/lib/geolocation';

type SourceFilter = 'all' | 'dummy' | 'report';
type PeriodFilter = 'all' | '7d' | '30d' | '90d' | '2025' | '2024' | '2023' | '2022' | '2021' | '2020';
type ControlTab = 'layer' | 'filter';
type TablePageSize = 5 | 10 | 25 | 50;

type DashboardIncident = {
    id: string | number;
    date?: string;
    time?: string;
    type?: string;
    kategori?: string;
    rawKategori?: string;
    description?: string;
    location?: string;
    status?: string;
    kecamatan?: string;
    desa?: string;
    lat: number;
    lng: number;
    latitude?: number;
    longitude?: number;
    reportCode?: string;
    source?: 'dummy' | 'report';
    title?: string;
    district?: string;
    village?: string;
    address?: string;
    photoUrl?: string | null;
    photo_url?: string | null;
    image_url?: string | null;
    imageUrl?: string | null;
    photoUrls?: string[];
    photo_urls?: string[];
    photos?: any[];
    severity?: number;
};

type KDEZoneLike = {
    id?: string | number;
    name?: string;
    kecamatan?: string;
    district?: string;
    center?: [number, number];
    lat?: number;
    lng?: number;
    latitude?: number;
    longitude?: number;
    score?: number;
    count?: number;
    total?: number;
    intensity?: string;
};

const SLEMAN_CENTER: [number, number] = [-7.716, 110.355];
const DEFAULT_ZOOM = 12;
const KDE_BANDWIDTH_KM = 1.65;

const SLEMAN_BOUNDS = {
    south: -7.86,
    north: -7.53,
    west: 110.2,
    east: 110.56,
};

const KDE_LEGEND_UI = [
    { label: 'Rendah', range: 'Area relatif rendah', color: '#22C55E', intensity: 'low' },
    { label: 'Sedang', range: 'Perlu dipantau', color: '#FACC15', intensity: 'medium' },
    { label: 'Tinggi', range: 'Area rawan', color: '#F97316', intensity: 'high' },
    { label: 'Sangat Tinggi', range: 'Prioritas utama', color: '#E11D48', intensity: 'very-high' },
];

const SLEMAN_KECAMATAN = [
    'Berbah',
    'Cangkringan',
    'Depok',
    'Gamping',
    'Godean',
    'Kalasan',
    'Minggir',
    'Mlati',
    'Moyudan',
    'Ngaglik',
    'Ngemplak',
    'Pakem',
    'Prambanan',
    'Seyegan',
    'Sleman',
    'Tempel',
    'Turi',
];

const periodOptions: Array<{ value: PeriodFilter; label: string }> = [
    { value: 'all', label: 'Semua waktu' },
    { value: '7d', label: '7 hari terakhir' },
    { value: '30d', label: '30 hari terakhir' },
    { value: '90d', label: '90 hari terakhir' },
    { value: '2025', label: 'Tahun 2025' },
    { value: '2024', label: 'Tahun 2024' },
    { value: '2023', label: 'Tahun 2023' },
    { value: '2022', label: 'Tahun 2022' },
    { value: '2021', label: 'Tahun 2021' },
    { value: '2020', label: 'Tahun 2020' },
];

const sourceOptions: Array<{ value: SourceFilter; label: string }> = [
    { value: 'all', label: 'Semua sumber' },
    { value: 'dummy', label: 'Data Polisi 2020–2025' },
    { value: 'report', label: 'Laporan Masyarakat' },
];

const tablePageSizeOptions: Array<{ value: string; label: string }> = [
    { value: '5', label: '5 kejadian' },
    { value: '10', label: '10 kejadian' },
    { value: '25', label: '25 kejadian' },
    { value: '50', label: '50 kejadian' },
];

const crimePalette: Record<string, { color: string; bg: string; label: string; weight: number }> = {
    PENGEROYOKAN: {
        color: '#EF4444',
        bg: '#FEE2E2',
        label: 'Pengeroyokan',
        weight: 1.25,
    },
    PENGRUSAKAN: {
        color: '#F97316',
        bg: '#FFEDD5',
        label: 'Pengrusakan',
        weight: 1.05,
    },
    PENGANIAYAAN: {
        color: '#EC4899',
        bg: '#FCE7F3',
        label: 'Penganiayaan',
        weight: 1.2,
    },
    'PENYALAHGUNAAN SENJATA TAJAM': {
        color: '#F59E0B',
        bg: '#FEF3C7',
        label: 'Senjata Tajam',
        weight: 1.45,
    },
    'PENCURIAN DENGAN KEKERASAN (CURAS)': {
        color: '#A855F7',
        bg: '#F3E8FF',
        label: 'Curas',
        weight: 1.4,
    },
    'PEMERASAN DAN PENGANCAMAN': {
        color: '#06B6D4',
        bg: '#CFFAFE',
        label: 'Pemerasan',
        weight: 1.15,
    },
};

const fallbackIncidentColors = ['#14B8A6', '#F97316', '#22C55E', '#E11D48', '#A855F7', '#06B6D4', '#F59E0B', '#EF4444'];

function getStableIncidentColor(value: string) {
    const text = String(value || 'Kejadian');
    const sum = Array.from(text).reduce((total, char) => total + char.charCodeAt(0), 0);
    return fallbackIncidentColors[sum % fallbackIncidentColors.length];
}

function cx(...classes: Array<string | false | null | undefined>) {
    return classes.filter(Boolean).join(' ');
}

function formatNumber(value: number) {
    return new Intl.NumberFormat('id-ID').format(value || 0);
}

function normalizeText(value: unknown) {
    return String(value ?? '')
        .toLowerCase()
        .trim();
}

function titleCase(value: unknown) {
    const text = String(value || '-').trim();

    if (!text || text === '-') return '-';

    return text
        .toLowerCase()
        .split(' ')
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
}

function getIncidentType(incident: any) {
    const props = incident?.properties || {};

    return String(
        incident?.rawKategori ||
            incident?.kategori ||
            incident?.crime_type ||
            incident?.incident_type ||
            incident?.type ||
            props?.rawKategori ||
            props?.kategori ||
            props?.KATEGORI ||
            props?.jenis_kejadian ||
            props?.JENIS_KEJADIAN ||
            props?.jenis ||
            props?.JENIS ||
            props?.kejadian ||
            props?.KEJADIAN ||
            'Kejadian',
    ).trim();
}

function getIncidentTypeLabel(type: string) {
    return crimePalette[type]?.label || titleCase(type);
}

function getIncidentColor(type: string) {
    return crimePalette[type]?.color || crimePalette[getIncidentTypeLabel(type)]?.color || getStableIncidentColor(type);
}

function getIncidentKecamatan(incident: any) {
    return String(incident?.kecamatan || incident?.district || incident?.wilayah || '-').trim() || '-';
}

function getIncidentDesa(incident: any) {
    return String(incident?.desa || incident?.village || '-').trim() || '-';
}

function getIncidentPhotoUrls(incident: any): string[] {
    const rawList = incident?.photo_urls ?? incident?.photoUrls ?? incident?.photos ?? incident?.images ?? [];
    const urls: string[] = [];

    if (Array.isArray(rawList)) {
        rawList.forEach((entry: any) => {
            const value = typeof entry === 'string'
                ? entry
                : entry?.photo_url ?? entry?.photoUrl ?? entry?.url ?? entry?.image_url ?? entry?.photo_path ?? entry?.path;

            if (value) urls.push(String(value));
        });
    }

    const primary =
        incident?.photo_url ||
        incident?.photoUrl ||
        incident?.image_url ||
        incident?.imageUrl ||
        incident?.attachment_url ||
        incident?.attachmentUrl ||
        incident?.evidence_url ||
        incident?.evidenceUrl ||
        null;

    if (primary) urls.unshift(String(primary));

    return Array.from(new Set(urls.filter(Boolean)));
}

function getIncidentPrimaryPhoto(incident: any) {
    return getIncidentPhotoUrls(incident)[0] ?? null;
}

function getIncidentAddress(incident: any) {
    return String(incident?.location || incident?.address || incident?.alamat || incident?.alamat_kejadian || '-').trim() || '-';
}

function getIncidentShortDescription(incident: any) {
    return String(incident?.description || incident?.deskripsi || incident?.keterangan || incident?.KETERANGAN || '-').trim() || '-';
}

function parseDateValue(value: unknown): Date | null {
    if (!value || value === '-') return null;

    const date = new Date(String(value));

    if (Number.isNaN(date.getTime())) return null;

    return date;
}

function getIncidentDate(incident: any): Date | null {
    return parseDateValue(incident?.date || incident?.incident_date || incident?.incident_at || incident?.created_at);
}

function inSlemanBounds(lat: number, lng: number) {
    return (
        Number.isFinite(lat) &&
        Number.isFinite(lng) &&
        lat >= SLEMAN_BOUNDS.south &&
        lat <= SLEMAN_BOUNDS.north &&
        lng >= SLEMAN_BOUNDS.west &&
        lng <= SLEMAN_BOUNDS.east
    );
}


function getDistanceKm(lat1: number, lng1: number, lat2: number, lng2: number) {
    const earthRadiusKm = 6371;
    const toRad = (value: number) => (value * Math.PI) / 180;
    const dLat = toRad(lat2 - lat1);
    const dLng = toRad(lng2 - lng1);
    const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
            Math.sin(dLng / 2) * Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return earthRadiusKm * c;
}

function formatDistance(km: number) {
    if (!Number.isFinite(km)) return '-';
    if (km < 1) return `${Math.round(km * 1000)} m`;
    return `${km.toFixed(2)} km`;
}

function getZoneLatLng(zone: KDEZoneLike) {
    const lat = Number(zone?.center?.[0] ?? zone?.lat ?? zone?.latitude ?? (zone as any)?.centerLat);
    const lng = Number(zone?.center?.[1] ?? zone?.lng ?? zone?.longitude ?? (zone as any)?.centerLng);

    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
    return { lat, lng };
}

function getZoneRadiusKm(zone: KDEZoneLike) {
    const radius = Number((zone as any)?.radius ?? (zone as any)?.radiusKm ?? KDE_BANDWIDTH_KM / 2);
    return Number.isFinite(radius) && radius > 0 ? radius : KDE_BANDWIDTH_KM / 2;
}

function getZoneIntensityLabel(value?: string) {
    const text = String(value || '').toLowerCase();
    if (text.includes('sangat')) return 'Sangat tinggi';
    if (text.includes('tinggi') || text.includes('high')) return 'Tinggi';
    if (text.includes('sedang') || text.includes('medium')) return 'Sedang';
    if (text.includes('rendah') || text.includes('low')) return 'Rendah';
    return 'Zona rawan';
}

function isInsidePeriod(incident: any, period: PeriodFilter) {
    if (period === 'all') return true;

    const date = getIncidentDate(incident);

    if (!date) return false;

    if (['2020', '2021', '2022', '2023', '2024', '2025'].includes(period)) {
        return String(date.getFullYear()) === period;
    }

    const today = new Date();
    const diffDays = (today.getTime() - date.getTime()) / (1000 * 60 * 60 * 24);

    if (period === '7d') return diffDays <= 7;
    if (period === '30d') return diffDays <= 30;
    if (period === '90d') return diffDays <= 90;

    return true;
}

function normalizeIncident(item: any, source: 'dummy' | 'report'): DashboardIncident | null {
    const props = item?.properties || {};
    const coordinates = item?.geometry?.coordinates;
    const geoLng = Array.isArray(coordinates) ? coordinates[0] : undefined;
    const geoLat = Array.isArray(coordinates) ? coordinates[1] : undefined;

    const lat = Number(item?.lat ?? item?.latitude ?? props?.lat ?? props?.latitude ?? props?.LAT ?? props?.Latitude ?? geoLat);
    const lng = Number(item?.lng ?? item?.longitude ?? item?.lon ?? props?.lng ?? props?.longitude ?? props?.LNG ?? props?.Longitude ?? geoLng);

    if (!inSlemanBounds(lat, lng)) return null;

    const merged = { ...props, ...item, lat, lng, latitude: lat, longitude: lng };
    const type = getIncidentType(merged);

    return {
        ...merged,
        id: item?.id ?? props?.id ?? props?.ID ?? `${source}-${lat}-${lng}-${type}`,
        date: String(item?.date || item?.incident_date || item?.incident_at || item?.created_at || props?.date || props?.tanggal || props?.TANGGAL || '-'),
        time: String(item?.time || item?.incident_time || props?.time || props?.jam || props?.WAKTU || '-'),
        type,
        kategori: type,
        rawKategori: type,
        description: String(item?.description || item?.deskripsi || item?.keterangan || props?.description || props?.deskripsi || props?.keterangan || props?.KETERANGAN || '-'),
        location: String(item?.location || item?.address || item?.alamat || props?.location || props?.alamat || props?.LOKASI || '-'),
        address: String(item?.address || item?.alamat || item?.location || props?.address || props?.alamat || props?.LOKASI || '-'),
        photoUrl: item?.photoUrl || item?.photo_url || item?.image_url || item?.imageUrl || props?.photoUrl || props?.photo_url || props?.image_url || null,
        photo_url: item?.photo_url || props?.photo_url || null,
        image_url: item?.image_url || props?.image_url || null,
        photoUrls: item?.photoUrls || item?.photo_urls || item?.photos || props?.photoUrls || props?.photo_urls || props?.photos || [],
        photo_urls: item?.photo_urls || props?.photo_urls || [],
        photos: item?.photos || props?.photos || [],
        status: item?.status || props?.status || 'Aktif',
        kecamatan: getIncidentKecamatan(merged),
        desa: getIncidentDesa(merged),
        lat,
        lng,
        latitude: lat,
        longitude: lng,
        source,
        severity: Number(item?.severity || props?.severity || crimePalette[type]?.weight || 1),
    };
}

function sortByLatest(a: DashboardIncident, b: DashboardIncident) {
    const dateA = getIncidentDate(a)?.getTime() ?? 0;
    const dateB = getIncidentDate(b)?.getTime() ?? 0;

    return dateB - dateA;
}

function getDominantLabel(items: Array<{ name: string; total: number }>) {
    if (!items.length) return '-';

    return items[0].name;
}

function getRiskTone(total: number) {
    if (total >= 80) {
        return {
            label: 'Perlu Atensi Tinggi',
            className: 'bg-rose-50 text-rose-700 border-rose-100',
        };
    }

    if (total >= 35) {
        return {
            label: 'Perlu Dipantau',
            className: 'bg-[#EFF4F8] text-[#D95F5F] border-[#D8E4ED]',
        };
    }

    return {
        label: 'Relatif Terkendali',
        className: 'bg-[#EFF4F8] text-[#D95F5F] border-[#D8E4ED]',
    };
}

function SmallButton({
    children,
    active,
    onClick,
    title,
}: {
    children: ReactNode;
    active?: boolean;
    onClick?: () => void;
    title?: string;
}) {
    return (
        <button
            type="button"
            onClick={onClick}
            title={title}
            className={cx(
                'inline-flex h-10 w-10 items-center justify-center rounded-2xl border text-slate-700 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md',
                active ? 'border-[#D8E4ED] bg-[#EFF4F8] text-[#1A3348]' : 'border-slate-200 bg-white hover:bg-[#EFF4F8] dark:bg-[#0F1F2E]/60',
            )}
        >
            {children}
        </button>
    );
}

function SelectField({
    label,
    value,
    onChange,
    options,
}: {
    label: string;
    value: string;
    onChange: (value: any) => void;
    options: Array<{ value: string; label: string }>;
}) {
    return (
        <label className="block">
            <span className="mb-1.5 block text-[11px] font-black uppercase tracking-[0.14em] text-slate-400">
                {label}
            </span>

            <div className="relative">
                <select
                    value={value}
                    onChange={(event) => onChange(event.target.value)}
                    className="h-11 w-full appearance-none rounded-2xl border border-[#D8E4ED] bg-white px-3 pr-9 text-sm font-bold text-[#0F1F2E] outline-none transition focus:border-[#D95F5F] focus:ring-4 focus:ring-[#D95F5F]/20 dark:border-white/10 dark:bg-[#1A3348] dark:text-[#EFF4F8] dark:focus:border-[#D95F5F] dark:focus:ring-[#D95F5F]/15"
                >
                    {options.map((option) => (
                        <option key={option.value} value={option.value}>
                            {option.label}
                        </option>
                    ))}
                </select>

                <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            </div>
        </label>
    );
}

function ToggleRow({
    title,
    subtitle,
    checked,
    onChange,
    icon,
}: {
    title: string;
    subtitle: string;
    checked: boolean;
    onChange: () => void;
    icon: ReactNode;
}) {
    return (
        <button
            type="button"
            onClick={onChange}
            className={cx(
                'flex w-full items-center gap-3 rounded-2xl border p-3 text-left transition hover:-translate-y-0.5 hover:shadow-md',
                checked ? 'border-[#D8E4ED] bg-[#EFF4F8]/80' : 'border-slate-200 bg-white hover:bg-[#EFF4F8] dark:bg-[#0F1F2E]/60',
            )}
        >
            <span
                className={cx(
                    'flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl',
                    checked ? 'bg-[#D95F5F] text-white' : 'bg-slate-100 text-slate-500',
                )}
            >
                {icon}
            </span>

            <span className="min-w-0 flex-1">
                <span className="block text-sm font-black text-slate-800">{title}</span>
                <span className="mt-0.5 block text-xs font-semibold leading-4 text-slate-500">{subtitle}</span>
            </span>

            <span className={cx('relative h-6 w-11 shrink-0 rounded-full transition', checked ? 'bg-[#D95F5F]' : 'bg-slate-200')}>
                <span
                    className={cx(
                        'absolute top-1 h-4 w-4 rounded-full bg-white shadow transition',
                        checked ? 'left-6' : 'left-1',
                    )}
                />
            </span>
        </button>
    );
}

function StatCard({
    title,
    value,
    subtitle,
    icon,
    tone = 'cyan',
}: {
    title: string;
    value: string;
    subtitle: string;
    icon: ReactNode;
    tone?: 'cyan' | 'rose' | 'amber' | 'emerald' | 'slate';
}) {
    const toneClass = {
        cyan: 'bg-[#EFF4F8] text-[#1A3348] border-[#D8E4ED]',
        rose: 'bg-rose-50 text-rose-700 border-rose-100',
        amber: 'bg-[#EFF4F8] text-[#D95F5F] border-[#D8E4ED]',
        emerald: 'bg-[#EFF4F8] text-[#D95F5F] border-[#D8E4ED]',
        slate: 'bg-[#EFF4F8] dark:bg-[#0F1F2E]/60 text-slate-700 border-slate-100',
    }[tone];

    return (
        <div className="rounded-[1.6rem] border border-[#D8E4ED] bg-white dark:border-white/10 dark:bg-[#1A3348] p-4 shadow-sm">
            <div className="flex items-start justify-between gap-3">
                <div>
                    <p className="text-xs font-black uppercase tracking-[0.14em] text-slate-400">{title}</p>
                    <p className="mt-2 text-2xl font-black tracking-tight text-foreground">{value}</p>
                </div>

                <div className={cx('flex h-11 w-11 items-center justify-center rounded-2xl border', toneClass)}>
                    {icon}
                </div>
            </div>

            <p className="mt-3 text-sm font-semibold leading-5 text-slate-500">{subtitle}</p>
        </div>
    );
}

function PanelTitle({ title, subtitle, icon }: { title: string; subtitle: string; icon: ReactNode }) {
    return (
        <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-slate-900 text-white">
                {icon}
            </div>

            <div>
                <h3 className="text-base font-black text-foreground">{title}</h3>
                <p className="mt-0.5 text-xs font-semibold leading-5 text-slate-500">{subtitle}</p>
            </div>
        </div>
    );
}

export default function AnalysisDashboard() {
    const mapRef = useRef<L.Map | null>(null);

    const [reportIncidents, setReportIncidents] = useState<MapIncident[]>([]);
    const [loadingReports, setLoadingReports] = useState(false);
    const [reportError, setReportError] = useState<string | null>(null);

    const [selectedPeriod, setSelectedPeriod] = useState<PeriodFilter>('all');
    const [selectedType, setSelectedType] = useState('all');
    const [selectedKecamatan, setSelectedKecamatan] = useState('all');
    const [selectedSource, setSelectedSource] = useState<SourceFilter>('all');
    const [activeTableSource, setActiveTableSource] = useState<'dummy' | 'report'>('report');
    const [searchQuery, setSearchQuery] = useState('');

    const [showIncident, setShowIncident] = useState(true);
    const [showKde, setShowKde] = useState(true);
    const [showDistrict, setShowDistrict] = useState(true);
    const [controlOpen, setControlOpen] = useState(true);
    const [layerSectionOpen, setLayerSectionOpen] = useState(true);
    const [legendSectionOpen, setLegendSectionOpen] = useState(true);
    const [mobileControlOpen, setMobileControlOpen] = useState(false);
    const [controlTab, setControlTab] = useState<ControlTab>('layer');
    const [isFullscreen, setIsFullscreen] = useState(false);
    const [tableOpen, setTableOpen] = useState(false);
    const [selectedTableYear, setSelectedTableYear] = useState('all');
    const [tablePageSize, setTablePageSize] = useState<TablePageSize>(10);
    const [tablePage, setTablePage] = useState(1);
    const [userLocation, setUserLocation] = useState<UserLocation | null>(null);
    const [isLocating, setIsLocating] = useState(false);

    const loadReports = useCallback(async () => {
        setLoadingReports(true);
        setReportError(null);

        try {
            const data = await fetchApprovedReportIncidents();
            setReportIncidents(data || []);
        } catch (error) {
            console.error('Gagal memuat laporan masyarakat:', error);
            setReportError('Laporan masyarakat belum berhasil dimuat. Data polisi tetap ditampilkan.');
            setReportIncidents([]);
        } finally {
            setLoadingReports(false);
        }
    }, []);

    useEffect(() => {
        loadReports();
    }, [loadReports]);

    const allIncidents = useMemo(() => {
        const dummy = (dummyIncidents || [])
            .map((item: any) => normalizeIncident(item, 'dummy'))
            .filter((item): item is DashboardIncident => Boolean(item));

        const reports = (reportIncidents || [])
            .map((item: any) => normalizeIncident(item, 'report'))
            .filter((item): item is DashboardIncident => Boolean(item));

        return [...dummy, ...reports].sort(sortByLatest);
    }, [reportIncidents]);

    const typeOptions = useMemo(() => {
        const values = Array.from(new Set(allIncidents.map((item) => getIncidentType(item))))
            .filter((value): value is string => Boolean(value))
            .sort();

        return [{ value: 'all', label: 'Semua jenis' }, ...values.map((value) => ({ value, label: getIncidentTypeLabel(value) }))];
    }, [allIncidents]);

    const kecamatanOptions = useMemo(() => {
        return [
            { value: 'all', label: 'Semua kecamatan' },
            ...SLEMAN_KECAMATAN.map((value) => ({ value, label: value })),
        ];
    }, []);

    const filteredIncidents = useMemo(() => {
        const query = normalizeText(searchQuery);

        return allIncidents.filter((incident) => {
            const type = getIncidentType(incident);
            const kecamatan = getIncidentKecamatan(incident);
            const source = incident.source || 'dummy';

            if (selectedType !== 'all' && type !== selectedType) return false;
            if (selectedKecamatan !== 'all' && normalizeText(kecamatan) !== normalizeText(selectedKecamatan)) return false;
            if (selectedSource !== 'all' && source !== selectedSource) return false;
            if (!isInsidePeriod(incident, selectedPeriod)) return false;

            if (query) {
                const haystack = normalizeText(
                    [
                        incident.title,
                        incident.description,
                        incident.location,
                        incident.address,
                        incident.kecamatan,
                        incident.desa,
                        type,
                        incident.reportCode,
                    ].join(' '),
                );

                if (!haystack.includes(query)) return false;
            }

            return true;
        });
    }, [allIncidents, searchQuery, selectedKecamatan, selectedPeriod, selectedSource, selectedType]);

    const tableYearOptions = useMemo(() => {
        const values = Array.from(
            new Set(
                filteredIncidents
                    .map((incident) => getIncidentDate(incident)?.getFullYear())
                    .filter((year): year is number => typeof year === 'number' && Number.isFinite(year)),
            ),
        ).sort((a: number, b: number) => b - a);

        return [
            { value: 'all', label: 'Semua tahun' },
            ...values.map((year) => ({ value: String(year), label: String(year) })),
        ];
    }, [filteredIncidents]);

    const tableIncidents = useMemo(() => {
        if (selectedTableYear === 'all') return filteredIncidents;

        return filteredIncidents.filter((incident) => {
            const year = getIncidentDate(incident)?.getFullYear();
            return String(year) === selectedTableYear;
        });
    }, [filteredIncidents, selectedTableYear]);

    const totalTablePages = Math.max(1, Math.ceil(tableIncidents.length / tablePageSize));

    const currentTablePage = Math.min(tablePage, totalTablePages);

    const paginatedTableIncidents = useMemo(() => {
        const start = (currentTablePage - 1) * tablePageSize;
        return tableIncidents.slice(start, start + tablePageSize);
    }, [currentTablePage, tableIncidents, tablePageSize]);

    const tableStartNumber = tableIncidents.length ? (currentTablePage - 1) * tablePageSize + 1 : 0;
    const tableEndNumber = Math.min(currentTablePage * tablePageSize, tableIncidents.length);

    useEffect(() => {
        setTablePage(1);
    }, [activeTableSource, searchQuery, selectedKecamatan, selectedPeriod, selectedSource, selectedTableYear, selectedType, tablePageSize]);

    const kdeZones = useMemo<KDEZoneLike[]>(() => {
        if (!filteredIncidents.length) return [];

        try {
            const result = analyzeKDE(filteredIncidents as any, KDE_BANDWIDTH_KM);
            return Array.isArray(result) ? result.slice(0, 6) : [];
        } catch (error) {
            console.error('Gagal membaca KDE:', error);
            return [];
        }
    }, [filteredIncidents]);

    const sourceStats = useMemo(() => {
        const dummy = filteredIncidents.filter((item) => item.source !== 'report').length;
        const report = filteredIncidents.filter((item) => item.source === 'report').length;

        return { dummy, report };
    }, [filteredIncidents]);

    const typeStats = useMemo(() => {
        const map = new Map<string, number>();

        filteredIncidents.forEach((incident) => {
            const type = getIncidentType(incident);
            map.set(type, (map.get(type) || 0) + 1);
        });

        return Array.from(map.entries())
            .map(([name, total]) => ({ name, total }))
            .sort((a, b) => b.total - a.total)
            .slice(0, 6);
    }, [filteredIncidents]);

    const kecamatanStats = useMemo(() => {
        const map = new Map<string, number>();

        filteredIncidents.forEach((incident) => {
            const name = getIncidentKecamatan(incident);

            if (!name || name === '-') return;

            map.set(name, (map.get(name) || 0) + 1);
        });

        return Array.from(map.entries())
            .map(([name, total]) => ({ name, total }))
            .sort((a, b) => b.total - a.total)
            .slice(0, 8);
    }, [filteredIncidents]);

    const latestIncidents = useMemo(() => filteredIncidents.slice(0, 8), [filteredIncidents]);

    const dominantType = getDominantLabel(typeStats.map((item) => ({ name: getIncidentTypeLabel(item.name), total: item.total })));
    const dominantKecamatan = getDominantLabel(kecamatanStats.map((item) => ({ name: titleCase(item.name), total: item.total })));
    const riskTone = getRiskTone(filteredIncidents.length);

    const activeFilterCount = [
        selectedPeriod !== 'all',
        selectedType !== 'all',
        selectedKecamatan !== 'all',
        selectedSource !== 'all',
        Boolean(searchQuery),
    ].filter(Boolean).length;

    const mapIncidents = showIncident ? filteredIncidents : [];

    const userRiskInfo = useMemo(() => {
        if (!userLocation) return null;

        const nearestZone = kdeZones
            .map((zone) => {
                const coordinate = getZoneLatLng(zone);
                if (!coordinate) return null;

                const centerDistanceKm = getDistanceKm(userLocation.lat, userLocation.lng, coordinate.lat, coordinate.lng);
                const radiusKm = getZoneRadiusKm(zone);
                const distanceToZoneKm = Math.max(0, centerDistanceKm - radiusKm);

                return {
                    zone,
                    coordinate,
                    radiusKm,
                    centerDistanceKm,
                    distanceToZoneKm,
                    inside: centerDistanceKm <= radiusKm,
                };
            })
            .filter(Boolean)
            .sort((a: any, b: any) => a.distanceToZoneKm - b.distanceToZoneKm)[0] as any;

        const nearestIncident = filteredIncidents
            .map((incident) => ({
                incident,
                distanceKm: getDistanceKm(userLocation.lat, userLocation.lng, incident.lat, incident.lng),
            }))
            .sort((a, b) => a.distanceKm - b.distanceKm)[0];

        const isInsideRawan = Boolean(nearestZone?.inside);
        const isNearRawan = Boolean(!isInsideRawan && nearestZone && nearestZone.distanceToZoneKm <= 0.5);
        const isNearIncident = Boolean(nearestIncident && nearestIncident.distanceKm <= 0.5);
        const status = isInsideRawan ? 'rawan' : isNearRawan || isNearIncident ? 'waspada' : 'aman';

        return {
            status,
            nearestZone,
            nearestIncident,
            title:
                status === 'rawan'
                    ? 'Anda berada di area rawan'
                    : status === 'waspada'
                      ? 'Anda berada dekat area rawan'
                      : 'Lokasi Anda relatif aman',
            message:
                status === 'rawan'
                    ? `Jarak Anda ke batas zona rawan adalah 0 m. Hindari berhenti terlalu lama, pilih rute ramai, dan segera hubungi kontak darurat bila situasi mencurigakan.`
                    : status === 'waspada'
                      ? `Jarak Anda ke batas zona rawan sekitar ${formatDistance(nearestZone?.distanceToZoneKm ?? Number.NaN)}. Tingkatkan kewaspadaan, perhatikan sekitar, dan gunakan jalur yang terang.`
                      : 'Tidak ada zona rawan yang sangat dekat dari posisi Anda saat ini. Tetap perhatikan kondisi sekitar.',
        };
    }, [filteredIncidents, kdeZones, userLocation]);

    const resetFilters = () => {
        setSelectedPeriod('all');
        setSelectedType('all');
        setSelectedKecamatan('all');
        setSelectedSource('all');
        setSearchQuery('');
    };

    const fitSleman = () => {
        mapRef.current?.setView(SLEMAN_CENTER, DEFAULT_ZOOM);
    };

    const zoomIn = () => {
        mapRef.current?.zoomIn();
    };

    const zoomOut = () => {
        mapRef.current?.zoomOut();
    };

    const zoomToIncident = (incident: DashboardIncident) => {
        setShowIncident(true);
        document.querySelector('.jaga-analysis-map-shell')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        window.setTimeout(() => {
            mapRef.current?.setView([incident.lat, incident.lng], 15, { animate: true });
        }, 260);
    };

    const zoomToKecamatan = (kecamatan: string) => {
        const points = filteredIncidents.filter((incident) => getIncidentKecamatan(incident) === kecamatan);

        if (!points.length) return;

        const bounds = L.latLngBounds(points.map((item) => [item.lat, item.lng] as [number, number]));
        mapRef.current?.fitBounds(bounds.pad(0.22), { animate: true, maxZoom: 14 });
    };

    const locateUser = () => {
        if (!navigator.geolocation) {
            alert('Browser belum mendukung fitur lokasi.');
            return;
        }

        setIsLocating(true);

        navigator.geolocation.getCurrentPosition(
            (position) => {
                const location = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude,
                    accuracy: position.coords.accuracy,
                } as UserLocation;

                const nearestZone = kdeZones
                    .map((zone) => {
                        const coordinate = getZoneLatLng(zone);
                        if (!coordinate) return null;

                        const centerDistanceKm = getDistanceKm(location.lat, location.lng, coordinate.lat, coordinate.lng);
                        const radiusKm = getZoneRadiusKm(zone);
                        const distanceToZoneKm = Math.max(0, centerDistanceKm - radiusKm);

                        return {
                            zone,
                            centerDistanceKm,
                            distanceToZoneKm,
                            radiusKm,
                            inside: centerDistanceKm <= radiusKm,
                        };
                    })
                    .filter(Boolean)
                    .sort((a: any, b: any) => a.distanceToZoneKm - b.distanceToZoneKm)[0] as any;

                const nearestIncident = filteredIncidents
                    .map((incident) => ({
                        incident,
                        distanceKm: getDistanceKm(location.lat, location.lng, incident.lat, incident.lng),
                    }))
                    .sort((a, b) => a.distanceKm - b.distanceKm)[0];

                setUserLocation(location);
                mapRef.current?.setView([location.lat, location.lng], 15, { animate: true });
                setIsLocating(false);

                if (nearestZone?.inside) {
                    alert(
                        `Peringatan! Posisi Anda berada di area rawan (${getZoneIntensityLabel(nearestZone.zone?.intensity)}). ` +
                            `Jarak Anda dari batas area rawan: 0 m. ` +
                            `Pusat zona sekitar ${formatDistance(nearestZone.centerDistanceKm)}, titik kejadian terdekat sekitar ${formatDistance(nearestIncident?.distanceKm ?? Number.NaN)}. ` +
                            `Himbauan: tetap bergerak ke area ramai dan hindari berhenti terlalu lama.`,
                    );
                } else if (nearestZone && nearestZone.distanceToZoneKm <= 0.5) {
                    alert(
                        `Waspada! Posisi Anda dekat area rawan. ` +
                            `Jarak Anda dari batas area rawan sekitar ${formatDistance(nearestZone.distanceToZoneKm)}. ` +
                            `Titik kejadian terdekat sekitar ${formatDistance(nearestIncident?.distanceKm ?? Number.NaN)}. ` +
                            `Himbauan: gunakan jalur terang, ramai, dan siapkan kontak darurat.`,
                    );
                }
            },
            () => {
                alert('Lokasi belum dapat diakses. Pastikan izin lokasi browser aktif.');
                setIsLocating(false);
            },
            {
                enableHighAccuracy: true,
                timeout: 12000,
                maximumAge: 0,
            },
        );
    };

    const controlContent = (
        <div className="space-y-3">
            <div className="overflow-hidden rounded-2xl border border-[#D8E4ED] bg-white">
                <button
                    type="button"
                    onClick={() => setLayerSectionOpen((value) => !value)}
                    className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left transition hover:bg-[#F8FAFC]"
                >
                    <span className="inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.14em] text-[#0F1F2E]">
                        <Layers3 className="h-4 w-4 text-[#D95F5F]" />
                        Layer Peta
                    </span>
                    {layerSectionOpen ? <ChevronUp className="h-4 w-4 text-slate-500" /> : <ChevronDown className="h-4 w-4 text-slate-500" />}
                </button>

                {layerSectionOpen && (
                    <div className="space-y-2.5 border-t border-[#D8E4ED] bg-[#F8FAFC] p-3">
                        <ToggleRow
                            title="KDE Hotspot"
                            subtitle="Tingkat kerawanan berdasarkan sebaran titik"
                            checked={showKde}
                            onChange={() => setShowKde((value) => !value)}
                            icon={<Flame className="h-5 w-5" />}
                        />

                        <ToggleRow
                            title="Titik Kejadian"
                            subtitle="Marker data polisi dan laporan warga"
                            checked={showIncident}
                            onChange={() => setShowIncident((value) => !value)}
                            icon={<MapPin className="h-5 w-5" />}
                        />

                        <ToggleRow
                            title="Batas Kecamatan"
                            subtitle="Garis batas wilayah administratif Sleman"
                            checked={showDistrict}
                            onChange={() => setShowDistrict((value) => !value)}
                            icon={<Shield className="h-5 w-5" />}
                        />
                    </div>
                )}
            </div>

            <div className="overflow-hidden rounded-2xl border border-[#D8E4ED] bg-white">
                <button
                    type="button"
                    onClick={() => setLegendSectionOpen((value) => !value)}
                    className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left transition hover:bg-[#F8FAFC]"
                >
                    <span className="inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.14em] text-[#0F1F2E]">
                        <Target className="h-4 w-4 text-[#D95F5F]" />
                        Legenda Titik
                    </span>
                    {legendSectionOpen ? <ChevronUp className="h-4 w-4 text-slate-500" /> : <ChevronDown className="h-4 w-4 text-slate-500" />}
                </button>

                {legendSectionOpen && (
                    <div className="space-y-2.5 border-t border-[#D8E4ED] bg-[#F8FAFC] p-3">
                        <div className="flex items-center gap-3 rounded-2xl bg-[#FFF8ED] px-3 py-2 ring-1 ring-[#FDE68A]">
                            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl border-2 border-white bg-[#FACC15] text-[10px] font-black text-[#422006] shadow-sm">LAP</span>
                            <span className="min-w-0">
                                <span className="block text-xs font-black text-[#0F1F2E]">Laporan Masyarakat</span>
                                <span className="block text-[11px] font-semibold leading-4 text-slate-500">Data laporan terverifikasi</span>
                            </span>
                        </div>

                        {typeStats.slice(0, 6).map((item) => (
                            <div key={item.name} className="flex items-center gap-3 rounded-2xl bg-white px-3 py-2 ring-1 ring-[#D8E4ED]">
                                <span
                                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border-2 border-white text-[10px] font-black text-white shadow-sm"
                                    style={{ backgroundColor: getIncidentColor(item.name) }}
                                >
                                    {String(getIncidentTypeLabel(item.name)).slice(0, 2).toUpperCase()}
                                </span>
                                <span className="min-w-0">
                                    <span className="block truncate text-xs font-black text-[#0F1F2E]">{getIncidentTypeLabel(item.name)}</span>
                                    <span className="block text-[11px] font-semibold leading-4 text-slate-500">{formatNumber(item.total)} titik pada filter aktif</span>
                                </span>
                            </div>
                        ))}

                        <div className="flex items-center gap-3 rounded-2xl bg-white px-3 py-2 ring-1 ring-[#D8E4ED]">
                            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl border-2 border-white bg-slate-400 text-[10px] font-black text-white shadow-sm">---</span>
                            <span className="min-w-0">
                                <span className="block text-xs font-black text-[#0F1F2E]">Batas Kecamatan</span>
                                <span className="block text-[11px] font-semibold leading-4 text-slate-500">Wilayah administrasi Kabupaten Sleman</span>
                            </span>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );

    const policeTableCount = filteredIncidents.filter((incident) => incident.source !== 'report').length;
    const reportTableCount = filteredIncidents.filter((incident) => incident.source === 'report').length;

    const activeTableIncidents = useMemo(() => {
        return tableIncidents.filter((incident) =>
            activeTableSource === 'report' ? incident.source === 'report' : incident.source !== 'report',
        );
    }, [activeTableSource, tableIncidents]);

    const totalDataPages = Math.max(1, Math.ceil(activeTableIncidents.length / tablePageSize));
    const currentDataPage = Math.min(tablePage, totalDataPages);
    const tableStartIndex = (currentDataPage - 1) * tablePageSize;
    const visibleTableIncidents = activeTableIncidents.slice(tableStartIndex, tableStartIndex + tablePageSize);
    const dataStartNumber = activeTableIncidents.length ? tableStartIndex + 1 : 0;
    const dataEndNumber = Math.min(tableStartIndex + tablePageSize, activeTableIncidents.length);

    const paginationItems = Array.from({ length: Math.min(totalDataPages, 5) }, (_, index) => {
        if (totalDataPages <= 5) return index + 1;
        if (currentDataPage <= 3) return index + 1;
        if (currentDataPage >= totalDataPages - 2) return totalDataPages - 4 + index;
        return currentDataPage - 2 + index;
    });

    const renderTable = () => (
        <div className="overflow-hidden rounded-[1.7rem] border border-[#D8E4ED] bg-white shadow-sm">
            <div className="flex flex-col gap-4 border-b border-[#D8E4ED] bg-white p-4 xl:flex-row xl:items-end xl:justify-between">
                <PanelTitle
                    title={activeTableSource === 'report' ? 'Data Laporan Masyarakat' : 'Data Kepolisian 2020–2025'}
                    subtitle={activeTableSource === 'report' ? 'Laporan warga terverifikasi sesuai filter aktif.' : 'Data kepolisian historis. Data pelaporan masyarakat tidak ditampilkan pada tabel ini.'}
                    icon={activeTableSource === 'report' ? <Shield className="h-5 w-5" /> : <Database className="h-5 w-5" />}
                />

                <div className="grid gap-3 sm:grid-cols-3 xl:min-w-[700px]">
                    <div className="relative sm:col-span-1">
                        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                        <input
                            value={searchQuery}
                            onChange={(event) => setSearchQuery(event.target.value)}
                            placeholder="Cari alamat, jenis, deskripsi..."
                            className="h-11 w-full rounded-2xl border border-[#D8E4ED] bg-white pl-10 pr-3 text-sm font-semibold text-[#0F1F2E] outline-none focus:border-[#D95F5F] focus:ring-4 focus:ring-[#D95F5F]/10"
                        />
                    </div>

                    <SelectField label="Periode waktu" value={selectedPeriod} onChange={setSelectedPeriod} options={periodOptions} />

                    <SelectField
                        label="Tampilkan"
                        value={String(tablePageSize)}
                        onChange={(value) => setTablePageSize(Number(value) as TablePageSize)}
                        options={tablePageSizeOptions}
                    />
                </div>
            </div>

            <div className="overflow-x-auto px-4 pb-3 pt-4">
                <table className="min-w-[920px] w-full text-left text-sm">
                    <thead className="bg-[#0F1F2E] text-[11px] uppercase tracking-[0.12em] text-white">
                        <tr>
                            <th className="px-4 py-3 font-black">No</th>
                            {activeTableSource === 'report' && <th className="px-4 py-3 font-black">Foto</th>}
                            <th className="px-4 py-3 font-black">Jenis Kejadian</th>
                            <th className="px-4 py-3 font-black">Waktu Kejadian</th>
                            <th className="px-4 py-3 font-black">Alamat</th>
                            <th className="px-4 py-3 font-black">{activeTableSource === 'report' ? 'Deskripsi Kejadian' : 'Deskripsi Singkat'}</th>
                            <th className="px-4 py-3 font-black">Aksi</th>
                        </tr>
                    </thead>

                    <tbody className="divide-y divide-[#D8E4ED] bg-white">
                        {visibleTableIncidents.length ? visibleTableIncidents.map((incident, index) => {
                            const type = getIncidentType(incident);
                            const color = getIncidentColor(type);
                            const photo = getIncidentPrimaryPhoto(incident);

                            return (
                                <tr key={`${activeTableSource}-${incident.id}`} className="transition hover:bg-[#FFF8ED]">
                                    <td className="whitespace-nowrap px-4 py-4 font-semibold text-[#0F1F2E]">
                                        {tableStartIndex + index + 1}
                                    </td>

                                    {activeTableSource === 'report' && (
                                        <td className="px-4 py-4">
                                            {photo ? (
                                                <img
                                                    src={photo}
                                                    alt={`Foto ${getIncidentTypeLabel(type)}`}
                                                    className="h-14 w-16 rounded-xl object-cover ring-1 ring-[#D8E4ED]"
                                                    onError={(event) => { event.currentTarget.style.display = 'none'; }}
                                                />
                                            ) : (
                                                <div className="flex h-14 w-16 items-center justify-center rounded-xl bg-[#F8FAFC] text-[10px] font-black text-slate-400 ring-1 ring-[#D8E4ED]">
                                                    Tidak ada
                                                </div>
                                            )}
                                        </td>
                                    )}

                                    <td className="px-4 py-4">
                                        <div className="flex min-w-[150px] items-center gap-2">
                                            <span className="h-3 w-3 shrink-0 rounded-full" style={{ backgroundColor: color }} />
                                            <span className="font-black text-[#0F1F2E]">{getIncidentTypeLabel(type)}</span>
                                        </div>
                                    </td>

                                    <td className="whitespace-nowrap px-4 py-4 font-semibold text-[#1A3348]/75">
                                        {incident.date || '-'}<br />{incident.time || '-'}
                                    </td>

                                    <td className="max-w-[300px] px-4 py-4 font-semibold text-[#1A3348]/75">
                                        <span className="line-clamp-2">{getIncidentAddress(incident)}</span>
                                    </td>

                                    <td className="max-w-[300px] px-4 py-4 font-semibold text-[#1A3348]/75">
                                        <span className="line-clamp-2">{getIncidentShortDescription(incident)}</span>
                                    </td>

                                    <td className="whitespace-nowrap px-4 py-4">
                                        <button
                                            type="button"
                                            onClick={() => zoomToIncident(incident)}
                                            className="rounded-xl bg-[#D95F5F] px-4 py-2 text-xs font-black text-white shadow-sm transition hover:bg-[#B94A4A]"
                                        >
                                            Lihat
                                        </button>
                                    </td>
                                </tr>
                            );
                        }) : (
                            <tr>
                                <td colSpan={activeTableSource === 'report' ? 7 : 6} className="px-4 py-10 text-center text-sm font-semibold text-[#1A3348]/70">
                                    Tidak ada data sesuai filter aktif.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>

            <div className="flex flex-col gap-3 border-t border-[#D8E4ED] bg-[#F8FAFC] px-4 py-4 sm:flex-row sm:items-center sm:justify-between">
                <p className="text-xs font-bold text-[#1A3348]/70">
                    Menampilkan {dataStartNumber}–{dataEndNumber} dari {activeTableIncidents.length} data. Klik tombol lihat untuk fokus ke marker peta.
                </p>

                <div className="flex flex-wrap items-center gap-2">
                    <button
                        type="button"
                        disabled={currentDataPage <= 1}
                        onClick={() => setTablePage((page) => Math.max(1, page - 1))}
                        className="rounded-xl border border-[#D8E4ED] bg-white px-3 py-2 text-xs font-black text-[#1A3348] disabled:cursor-not-allowed disabled:opacity-45"
                    >
                        Sebelumnya
                    </button>

                    {paginationItems.map((page) => (
                        <button
                            key={page}
                            type="button"
                            onClick={() => setTablePage(page)}
                            className={cx(
                                'h-9 w-9 rounded-xl text-xs font-black transition',
                                page === currentDataPage ? 'bg-[#0F1F2E] text-white' : 'border border-[#D8E4ED] bg-white text-[#1A3348] hover:bg-[#FFF8ED]',
                            )}
                        >
                            {page}
                        </button>
                    ))}

                    <button
                        type="button"
                        disabled={currentDataPage >= totalDataPages}
                        onClick={() => setTablePage((page) => Math.min(totalDataPages, page + 1))}
                        className="rounded-xl bg-[#0F1F2E] px-3 py-2 text-xs font-black text-white disabled:cursor-not-allowed disabled:opacity-45"
                    >
                        Berikutnya
                    </button>
                </div>
            </div>
        </div>
    );

    return (
        <main className={cx('jaga-analysis-page bg-[#EFF4F8] text-foreground', isFullscreen ? 'fixed inset-0 z-[9999] overflow-hidden p-0' : 'min-h-screen')}>
            <style>{`
                .jaga-analysis-page,
                .jaga-analysis-page * {
                    text-shadow: none !important;
                    box-sizing: border-box;
                }

                .jaga-analysis-page .leaflet-control-zoom,
                .jaga-analysis-page .jagasleman-map-action-controls,
                .jaga-analysis-page .jagasleman-kde-legend {
                    display: none !important;
                }

                .jaga-analysis-page .jagasleman-basemap-panel {
                    top: 76px !important;
                    left: 16px !important;
                    z-index: 646 !important;
                }

                .jaga-analysis-page .jagasleman-basemap-toggle {
                    width: 40px !important;
                    height: 40px !important;
                    border-radius: 16px !important;
                    box-shadow: 0 12px 28px rgba(15,31,46,.16) !important;
                }

                .jaga-analysis-page .jagasleman-basemap-menu {
                    margin-top: 10px !important;
                    width: 238px !important;
                }

                @media (max-width: 768px) {
                    .jaga-analysis-page .jagasleman-basemap-panel {
                        top: 72px !important;
                        left: 16px !important;
                    }
                }

                .jaga-analysis-map-shell .leaflet-popup-content-wrapper {
                    border-radius: 20px !important;
                    overflow: hidden !important;
                    border: 1px solid #D8E4ED !important;
                    box-shadow: 0 24px 60px rgba(15, 23, 42, 0.22) !important;
                    background: #ffffff !important;
                }

                .jaga-analysis-map-shell .leaflet-popup-content {
                    margin: 0 !important;
                    color: #0F1F2E !important;
                }

                .jaga-analysis-map-shell .leaflet-popup-tip {
                    background: #ffffff !important;
                }

                .jaga-analysis-kde-gradient {
                    background: linear-gradient(90deg, #22C55E 0%, #FACC15 34%, #F97316 66%, #E11D48 100%);
                }

                .jaga-analysis-control-scroll::-webkit-scrollbar {
                    width: 7px;
                }

                .jaga-analysis-control-scroll::-webkit-scrollbar-thumb {
                    background: rgba(100, 116, 139, 0.34);
                    border-radius: 999px;
                }

                @media (max-width: 1024px) {
                    .jaga-analysis-map-height {
                        height: 540px !important;
                        min-height: 520px !important;
                    }
                }

                @media (max-width: 640px) {
                    .jaga-analysis-map-height {
                        height: 460px !important;
                        min-height: 430px !important;
                    }
                }
            `}</style>

            <div className={cx('mx-auto w-full', isFullscreen ? 'h-screen max-w-none p-0' : 'max-w-[1560px] px-4 py-5 sm:px-6 lg:px-8')}>
                {!isFullscreen && (
                    <>
                        <header className="mb-5 overflow-hidden rounded-[2rem] border border-[#D8E4ED] bg-white p-5 shadow-sm">
                            <div className="grid gap-5 lg:grid-cols-[1fr_auto] lg:items-start">
                                <div className="max-w-3xl">
                                    <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-[#EFF4F8] px-3 py-1.5 text-xs font-black text-[#1A3348]">
                                        <Target className="h-4 w-4" />
                                        Analisis Peta Kejahatan Jalanan
                                    </div>

                                    <h1 className="text-2xl font-black tracking-tight text-[#0F1F2E] sm:text-3xl">
                                        Peta Hotspot JagaSleman
                                    </h1>

                                    <p className="mt-2 max-w-2xl text-sm font-semibold leading-6 text-slate-500">
                                        Pantau titik kejadian, pola kerawanan, dan laporan terbaru dalam satu tampilan peta yang ringkas.
                                    </p>
                                </div>

                                <div className="rounded-[1.4rem] border border-[#D8E4ED] bg-[#F8FAFC] px-4 py-3 text-sm font-bold text-[#1A3348]">
                                    Filter peta mengikuti data pada tabel di bawah.
                                </div>
                            </div>

                            <div className="mt-5 grid gap-4 md:grid-cols-3">
                                <StatCard
                                    title="Total Titik"
                                    value={formatNumber(filteredIncidents.length)}
                                    subtitle="Data sesuai filter aktif"
                                    icon={<MapPin className="h-5 w-5" />}
                                    tone="slate"
                                />

                                <StatCard
                                    title="Data Polisi"
                                    value={formatNumber(sourceStats.dummy)}
                                    subtitle="Rekaman historis 2020–2025"
                                    icon={<Database className="h-5 w-5" />}
                                    tone="amber"
                                />

                                <StatCard
                                    title="Laporan Warga"
                                    value={formatNumber(sourceStats.report)}
                                    subtitle={loadingReports ? 'Sedang memuat data...' : 'Data dari form laporan'}
                                    icon={<Shield className="h-5 w-5" />}
                                    tone="emerald"
                                />
                            </div>
                        </header>

                        <section className="mb-5 rounded-[1.7rem] border border-[#E8D5BE] bg-[#FFF8ED] p-4 shadow-sm">
                            <div className="flex gap-3">
                                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-[#FDE68A] text-[#92400E]">
                                    <Shield className="h-5 w-5" />
                                </div>

                                <div>
                                    <h2 className="text-sm font-black text-[#0F1F2E]">Panduan Peta</h2>
                                    <p className="mt-1 text-xs font-semibold leading-relaxed text-[#1A3348]/75">
                                        Gunakan <b>Keterangan Peta</b> untuk mengatur layer dan legenda marker. Klik marker untuk membaca detail. Tombol <Maximize2 className="mx-1 inline h-4 w-4 align-[-3px]" /> digunakan untuk membuka tampilan fullscreen.
                                    </p>
                                </div>
                            </div>
                        </section>
                    </>
                )}

                <section className={cx('grid gap-5', isFullscreen ? 'h-screen grid-cols-1' : 'grid-cols-1')}>
                    <div
                        className={cx(
                            'jaga-analysis-map-shell relative overflow-hidden border border-[#D8E4ED] bg-white shadow-xl shadow-slate-950/8',
                            isFullscreen ? 'h-screen rounded-none border-0' : 'jaga-analysis-map-height h-[calc(100vh-245px)] min-h-[620px] rounded-[2rem]',
                        )}
                    >
                        <MapView
                            ref={mapRef}
                            center={SLEMAN_CENTER}
                            zoom={DEFAULT_ZOOM}
                            incidents={mapIncidents as any}
                            contacts={[]}
                            showHeatmap={showKde}
                            heatmapBandwidthKm={KDE_BANDWIDTH_KM}
                            hotspotClusters={[]}
                            userLocation={userLocation}
                            showDistrictBoundary={showDistrict}
                            fitDistrictBoundary
                            showVillageBoundary={false}
                            villageBoundaryInteractive={false}
                            showMapControls={false}
                            showKdeLegend={false}
                        />

                        <div className="pointer-events-none absolute inset-x-4 top-4 z-[640] flex flex-wrap items-start justify-between gap-3">
                            <div className="pointer-events-auto flex flex-wrap items-center gap-2 rounded-[1.35rem] border border-white/80 bg-white/95 p-2 shadow-xl shadow-slate-950/12 backdrop-blur-xl">
                                <SmallButton onClick={zoomIn} title="Perbesar peta"><Plus className="h-4 w-4" /></SmallButton>
                                <SmallButton onClick={zoomOut} title="Perkecil peta"><Minus className="h-4 w-4" /></SmallButton>
                                <SmallButton onClick={fitSleman} title="Kembali ke Sleman"><Crosshair className="h-4 w-4" /></SmallButton>
                                <SmallButton onClick={locateUser} active={Boolean(userLocation)} title="Lokasi Saya"><LocateFixed className={cx('h-4 w-4', isLocating && 'animate-pulse')} /></SmallButton>
                                <SmallButton onClick={() => setIsFullscreen((value) => !value)} active={isFullscreen} title="Fullscreen">
                                    {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
                                </SmallButton>
                            </div>

                            <button
                                type="button"
                                onClick={() => setControlOpen((value) => !value)}
                                className="pointer-events-auto hidden items-center gap-2 rounded-2xl bg-slate-950 px-4 py-3 text-sm font-black text-white shadow-2xl shadow-slate-950/16 transition hover:bg-[#1A3348] lg:inline-flex"
                            >
                                <SlidersHorizontal className="h-4 w-4" />
                                Keterangan Peta
                            </button>
                        </div>

                        {userRiskInfo && (
                            <div
                                className={cx(
                                    'absolute left-4 top-[86px] z-[645] max-w-[430px] rounded-[1.6rem] border p-4 shadow-2xl backdrop-blur-xl',
                                    userRiskInfo.status === 'rawan'
                                        ? 'border-red-200 bg-red-50/95 text-red-900 shadow-red-950/10'
                                        : userRiskInfo.status === 'waspada'
                                          ? 'border-amber-200 bg-amber-50/95 text-amber-900 shadow-amber-950/10'
                                          : 'border-emerald-200 bg-emerald-50/95 text-emerald-900 shadow-emerald-950/10',
                                )}
                            >
                                <div className="flex items-start gap-3">
                                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-white/70 text-current">
                                        {userRiskInfo.status === 'aman' ? <Shield className="h-5 w-5" /> : <AlertTriangle className="h-5 w-5" />}
                                    </div>

                                    <div className="min-w-0">
                                        <p className="text-sm font-black">{userRiskInfo.title}</p>
                                        <p className="mt-1 text-xs font-semibold leading-5 opacity-80">{userRiskInfo.message}</p>
                                    </div>
                                </div>
                            </div>
                        )}

                        {controlOpen && (
                            <aside className="absolute right-4 top-[86px] z-[650] hidden w-[350px] max-w-[calc(100%-2rem)] lg:block">
                                <div className="jaga-analysis-control-scroll max-h-[calc(100vh-8rem)] overflow-y-auto rounded-[1.8rem] border border-white/80 bg-white/95 p-3 shadow-2xl shadow-slate-950/16 backdrop-blur-xl">
                                    <div className="mb-3 flex items-start justify-between gap-3 rounded-[1.45rem] bg-slate-950 px-4 py-3 text-white">
                                        <div>
                                            <p className="text-sm font-black">Keterangan Peta</p>
                                            <p className="mt-1 text-[11px] font-semibold leading-4 text-white/60">Atur layer, filter data, dan legenda marker.</p>
                                        </div>

                                        <button type="button" onClick={() => setControlOpen(false)} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-white/10 text-white transition hover:bg-white/20">
                                            <X className="h-4 w-4" />
                                        </button>
                                    </div>

                                    {controlContent}
                                </div>
                            </aside>
                        )}

                        <button
                            type="button"
                            onClick={() => setMobileControlOpen(true)}
                            className="absolute bottom-4 right-4 z-[650] inline-flex items-center gap-2 rounded-2xl bg-slate-950 px-4 py-3 text-sm font-black text-white shadow-2xl shadow-slate-950/20 lg:hidden"
                        >
                            <SlidersHorizontal className="h-4 w-4" />
                            Kontrol
                        </button>

                        {showKde && (
                            <div className="absolute bottom-4 left-1/2 z-[630] w-[min(520px,calc(100%-2rem))] -translate-x-1/2 rounded-[1.35rem] border border-white/80 bg-white/95 p-3 shadow-xl shadow-slate-950/12 backdrop-blur-xl">
                                <div className="mb-2 flex items-center justify-between gap-3">
                                    <span className="text-[11px] font-black uppercase tracking-[0.16em] text-[#0F1F2E]">Tingkat Kerawanan</span>
                                    <span className="text-[10px] font-bold text-slate-500">Rendah – Sangat Tinggi</span>
                                </div>

                                <div className="jaga-analysis-kde-gradient h-2.5 rounded-full" />

                                <div className="mt-2 grid grid-cols-2 gap-2 text-[11px] font-black text-slate-600 sm:grid-cols-4">
                                    {KDE_LEGEND_UI.map((item) => (
                                        <div key={item.intensity} className="flex items-center gap-1.5">
                                            <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                                            {item.label}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {reportError && (
                            <div className="absolute left-4 top-[86px] z-[640] max-w-sm rounded-2xl border border-[#D8E4ED] bg-[#EFF4F8] p-3 text-xs font-bold leading-5 text-[#0F1F2E] shadow-xl">
                                {reportError}
                            </div>
                        )}
                    </div>

                    {!isFullscreen && (
                        <section className="rounded-[2rem] border border-[#D8E4ED] bg-white p-4 shadow-sm">
                            <div className="mb-4 flex flex-wrap gap-2 border-b border-[#D8E4ED] pb-3">
                                <button
                                    type="button"
                                    onClick={() => setActiveTableSource('report')}
                                    className={cx(
                                        'inline-flex items-center gap-2 rounded-t-2xl px-4 py-3 text-sm font-black shadow-sm transition',
                                        activeTableSource === 'report' ? 'bg-[#D95F5F] text-white' : 'bg-[#FFF8ED] text-[#7C2D12] ring-1 ring-[#E8D5BE] hover:bg-[#FDE68A]',
                                    )}
                                >
                                    <Shield className="h-4 w-4" />
                                    Laporan Masyarakat ({reportTableCount})
                                </button>

                                <button
                                    type="button"
                                    onClick={() => setActiveTableSource('dummy')}
                                    className={cx(
                                        'inline-flex items-center gap-2 rounded-t-2xl px-4 py-3 text-sm font-black shadow-sm transition',
                                        activeTableSource === 'dummy' ? 'bg-[#0F1F2E] text-white' : 'bg-[#FFF8ED] text-[#7C2D12] ring-1 ring-[#E8D5BE] hover:bg-[#FDE68A]',
                                    )}
                                >
                                    <Database className="h-4 w-4" />
                                    Data Kepolisian 2020–2025 ({policeTableCount})
                                </button>
                            </div>

                            {renderTable()}
                        </section>
                    )}
                </section>
            </div>

            {mobileControlOpen && (
                <div className="fixed inset-0 z-[10000] bg-slate-950/45 p-4 backdrop-blur-sm lg:hidden">
                    <div className="ml-auto flex h-full max-w-md flex-col rounded-[2rem] bg-white p-4 shadow-2xl">
                        <div className="mb-3 flex items-center justify-between gap-3">
                            <div>
                                <p className="text-base font-black text-foreground">Kontrol Peta</p>
                                <p className="text-xs font-semibold text-slate-500">Atur layer dan filter data.</p>
                            </div>

                            <button type="button" onClick={() => setMobileControlOpen(false)} className="flex h-10 w-10 items-center justify-center rounded-2xl bg-slate-100 text-slate-500">
                                <X className="h-5 w-5" />
                            </button>
                        </div>

                        <div className="min-h-0 flex-1 overflow-y-auto pr-1">{controlContent}</div>
                    </div>
                </div>
            )}
        </main>
    );
}
