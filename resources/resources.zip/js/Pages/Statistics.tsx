import { useEffect, useMemo, useState, type FormEvent } from 'react';
import {
    Activity,
    AlertCircle,
    BarChart3,
    CalendarDays,
    CheckCircle2,
    ChevronDown,
    ChevronUp,
    Clock3,
    Database,
    Download,
    FileWarning,
    Loader2,
    Mail,
    Map as MapIcon,
    MapPin,
    RefreshCcw,
    Search,
    ShieldAlert,
    TrendingUp,
    XCircle,
} from 'lucide-react';
import {
    Bar,
    BarChart,
    CartesianGrid,
    Cell,
    Pie,
    PieChart,
    ResponsiveContainer,
    Tooltip,
    XAxis,
    YAxis,
} from 'recharts';
import { incidents as dummyIncidents } from '@/data/dummy';

type ReportRecord = {
    id?: string | number;
    report_code?: string;
    reportCode?: string;
    title?: string;
    incident_type?: string;
    crime_type?: string;
    type?: string;
    kategori?: string;
    category?: string;
    description?: string;
    location?: string;
    address?: string;
    district?: string;
    kecamatan?: string;
    village?: string;
    desa?: string;
    latitude?: string | number;
    longitude?: string | number;
    incident_at?: string;
    incident_date?: string;
    date?: string;
    created_at?: string;
    status?: string;
    source?: string;
};

type MonthlyStat = {
    month: string;
    total: number;
    month_number?: number;
};

type CategoryStat = {
    name: string;
    value: number;
    fill?: string;
};

type DistrictStat = {
    name: string;
    total: number;
};

type RecentReport = {
    id?: string | number;
    report_code?: string;
    title?: string;
    type?: string;
    district?: string;
    village?: string;
    date?: string;
    status?: string;
    source?: string;
};

type StatusLookupResult = {
    id?: string | number;
    report_code?: string;
    title?: string;
    incident_type?: string;
    location?: string;
    district?: string;
    village?: string;
    incident_at?: string;
    status?: string;
    status_label?: string;
    rejection_reason?: string | null;
    reviewed_at?: string | null;
    created_at?: string | null;
};

type StatisticPayload = {
    summary: {
        total: number;
        pending: number;
        approved: number;
        rejected: number;
        districts: number;
        top_district: string;
        avg_per_month: number;
    };
    monthly: MonthlyStat[];
    categories: CategoryStat[];
    districts: DistrictStat[];
    recent_reports: RecentReport[];
    recent_police_reports?: RecentReport[];
    recent_community_reports?: RecentReport[];
    available_years: string[];
    updated_at?: string | null;
    source: 'database' | 'map-api' | 'dummy';
};

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
const CATEGORY_COLORS = ['#334155', '#D95F5F', '#0EA5E9', '#F59E0B', '#8B5CF6', '#14B8A6', '#22C55E', '#E11D48'];
const CURRENT_YEAR = '2026';

function numberFormat(value: number) {
    return new Intl.NumberFormat('id-ID').format(Number(value || 0));
}

function formatDate(value?: string | null) {
    if (!value || value === '-') return '-';

    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;

    return new Intl.DateTimeFormat('id-ID', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
    }).format(date);
}

function normalizeStatus(value?: string | null) {
    const text = String(value || '').toLowerCase().trim();

    if (['approved', 'approve', 'diterima', 'disetujui', 'verified', 'aktif', 'selesai'].includes(text)) return 'approved';
    if (['rejected', 'reject', 'ditolak', 'invalid'].includes(text)) return 'rejected';
    return 'pending';
}

function statusLabel(value?: string | null) {
    const status = normalizeStatus(value);
    if (status === 'approved') return 'Terverifikasi';
    if (status === 'rejected') return 'Ditolak';
    return 'Menunggu';
}

function statusClass(value?: string | null) {
    const status = normalizeStatus(value);
    if (status === 'approved') return 'border-emerald-200 bg-emerald-50 text-emerald-700';
    if (status === 'rejected') return 'border-rose-200 bg-rose-50 text-rose-700';
    return 'border-amber-200 bg-amber-50 text-amber-700';
}

function getDataSourceLabel(source?: string) {
    if (source === 'database') return 'Pelaporan Masyarakat';
    if (source === 'map-api') return 'Data Kejadian Kepolisian';
    if (source === 'dummy') return 'Data Kepolisian Lokal';
    return 'Data Statistik';
}

function getDataSourceDescription(source?: string) {
    if (source === 'database') {
        return 'Data berasal dari hasil pelaporan masyarakat melalui formulir JagaSleman dan dapat dicek menggunakan email serta kode laporan.';
    }

    if (source === 'map-api') {
        return 'Data berasal dari GeoJSON atau data kejadian kepolisian. Data ini dibaca sebagai kejadian kepolisian, bukan pelaporan masyarakat.';
    }

    if (source === 'dummy') {
        return 'Data lokal digunakan sebagai data kejadian kepolisian ketika API statistik belum tersedia.';
    }

    return 'Data digunakan untuk membaca tren kejadian dan pelaporan.';
}

function getRecentSourceLabel(item: RecentReport) {
    const source = String(item.source || '').toLowerCase();
    const code = String(item.report_code || '').toUpperCase();

    if (source === 'database' || source === 'community' || code.startsWith('LAP-')) {
        return 'Pelaporan';
    }

    return 'Data Kepolisian';
}

function getReportDate(item: ReportRecord) {
    return item.incident_at || item.incident_date || item.date || item.created_at || '';
}

function getReportYear(item: ReportRecord) {
    const value = getReportDate(item);
    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        const text = String(value || '');
        const match = text.match(/(20\d{2})/);
        return match?.[1] || CURRENT_YEAR;
    }

    return String(date.getFullYear());
}

function getReportMonthIndex(item: ReportRecord) {
    const value = getReportDate(item);
    const date = new Date(value);

    if (!Number.isNaN(date.getTime())) return date.getMonth();

    const monthText = String(value || '').slice(5, 7);
    const month = Number(monthText);
    if (month >= 1 && month <= 12) return month - 1;

    return new Date().getMonth();
}

function normalizeType(item: ReportRecord) {
    return String(
        item.incident_type ||
        item.crime_type ||
        item.type ||
        item.kategori ||
        item.category ||
        'Tidak diketahui'
    ).trim() || 'Tidak diketahui';
}

function normalizeDistrict(item: ReportRecord) {
    return String(item.district || item.kecamatan || 'Belum terdeteksi').trim() || 'Belum terdeteksi';
}

function normalizeVillage(item: ReportRecord) {
    return String(item.village || item.desa || '-').trim() || '-';
}

function normalizeRecentReportItem(item: ReportRecord | any, index = 0, source: string = 'database'): RecentReport {
    const sourceType = String(item.source || source || '').toLowerCase();
    const code = String(item.report_code || item.reportCode || item.kode_laporan || '').toUpperCase();
    const isPoliceData = ['police', 'map-api', 'dummy'].includes(sourceType) || code.startsWith('POL-');
    const rawId = String(item.id ?? index + 1).replace(/^police-/i, '').replace(/^report-/i, '').replace(/^laporan-/i, '');
    const fallbackCode = isPoliceData
        ? `POL-${rawId.padStart(4, '0')}`
        : `LAP-${rawId.padStart(4, '0')}`;

    return {
        id: item.id,
        report_code: item.report_code || item.reportCode || item.kode_laporan || fallbackCode,
        title: item.title || normalizeType(item),
        type: normalizeType(item),
        district: normalizeDistrict(item),
        village: normalizeVillage(item),
        date: getReportDate(item),
        status: item.status || (isPoliceData ? 'approved' : 'pending'),
        source: item.source || (isPoliceData ? 'police' : source),
    };
}

function isCommunityRecentReport(item: RecentReport) {
    return getRecentSourceLabel(item) === 'Pelaporan';
}

function isPoliceRecentReport(item: RecentReport) {
    return !isCommunityRecentReport(item);
}

function extractReports(payload: any): ReportRecord[] {
    if (Array.isArray(payload)) return payload;
    if (Array.isArray(payload?.data)) return payload.data;
    if (Array.isArray(payload?.reports)) return payload.reports;
    if (Array.isArray(payload?.incident_reports)) return payload.incident_reports;
    if (Array.isArray(payload?.incidents)) return payload.incidents;

    if (Array.isArray(payload?.features)) {
        return payload.features.map((feature: any) => {
            const props = feature?.properties || {};
            const coordinates = feature?.geometry?.coordinates || [];

            return {
                ...props,
                longitude: coordinates[0],
                latitude: coordinates[1],
            };
        });
    }

    return [];
}

function normalizeApiStatistics(payload: any, selectedYear: string): StatisticPayload | null {
    if (!payload || !payload.summary) return null;

    const monthly = Array.isArray(payload.monthly)
        ? payload.monthly.map((item: any, index: number) => ({
            month: String(item.month || MONTHS[index] || '-'),
            total: Number(item.total || item.value || 0),
            month_number: Number(item.month_number || index + 1),
        }))
        : MONTHS.map((month, index) => ({ month, total: 0, month_number: index + 1 }));

    const categories = Array.isArray(payload.categories)
        ? payload.categories.map((item: any, index: number) => ({
            name: String(item.name || item.type || item.category || 'Tidak diketahui'),
            value: Number(item.value || item.total || 0),
            fill: item.fill || CATEGORY_COLORS[index % CATEGORY_COLORS.length],
        }))
        : [];

    const districts = Array.isArray(payload.districts)
        ? payload.districts.map((item: any) => ({
            name: String(item.name || item.district || item.kecamatan || 'Belum terdeteksi'),
            total: Number(item.total || item.value || 0),
        }))
        : [];

    const total = Number(payload.summary.total || 0);
    const normalizedRecentReports = Array.isArray(payload.recent_reports)
        ? payload.recent_reports.map((item: any, index: number) => normalizeRecentReportItem({ ...item, source: item.source || 'database' }, index, 'database'))
        : [];
    const normalizedPoliceReports = Array.isArray(payload.recent_police_reports)
        ? payload.recent_police_reports.map((item: any, index: number) => normalizeRecentReportItem({ ...item, source: item.source || 'police' }, index, 'police'))
        : normalizedRecentReports.filter(isPoliceRecentReport);
    const normalizedCommunityReports = Array.isArray(payload.recent_community_reports)
        ? payload.recent_community_reports.map((item: any, index: number) => normalizeRecentReportItem({ ...item, source: item.source || 'database' }, index, 'database'))
        : normalizedRecentReports.filter(isCommunityRecentReport);

    return {
        summary: {
            total,
            pending: Number(payload.summary.pending || 0),
            approved: Number(payload.summary.approved || 0),
            rejected: Number(payload.summary.rejected || 0),
            districts: Number(payload.summary.districts || districts.length || 0),
            top_district: String(payload.summary.top_district || districts[0]?.name || '-'),
            avg_per_month: Number(payload.summary.avg_per_month || (total / 12)),
        },
        monthly,
        categories,
        districts,
        recent_reports: normalizedRecentReports,
        recent_police_reports: normalizedPoliceReports,
        recent_community_reports: normalizedCommunityReports,
        available_years: Array.isArray(payload.available_years) && payload.available_years.length
            ? payload.available_years.map(String)
            : [selectedYear],
        updated_at: payload.updated_at || null,
        source: 'database',
    };
}

function buildStatisticsFromReports(
    reports: ReportRecord[],
    selectedYear: string,
    source: 'map-api' | 'dummy'
): StatisticPayload {
    const allYears = Array.from(new Set(reports.map(getReportYear)))
        .filter(Boolean)
        .sort((a, b) => Number(b) - Number(a));

    const filteredReports = selectedYear === 'all'
        ? reports
        : reports.filter((item) => getReportYear(item) === selectedYear);

    const monthlyMap = new globalThis.Map<number, number>();
    MONTHS.forEach((_, index) => monthlyMap.set(index, 0));

    const categoryMap = new globalThis.Map<string, number>();
    const districtMap = new globalThis.Map<string, number>();

    let pending = 0;
    let approved = 0;
    let rejected = 0;

    filteredReports.forEach((item) => {
        const monthIndex = getReportMonthIndex(item);
        monthlyMap.set(monthIndex, (monthlyMap.get(monthIndex) || 0) + 1);

        const type = normalizeType(item);
        categoryMap.set(type, (categoryMap.get(type) || 0) + 1);

        const district = normalizeDistrict(item);
        districtMap.set(district, (districtMap.get(district) || 0) + 1);

        const status = normalizeStatus(item.status);

        if (status === 'approved') {
            approved += 1;
        } else if (status === 'rejected') {
            rejected += 1;
        } else {
            pending += 1;
        }
    });

    const monthly = MONTHS.map((month, index) => ({
        month,
        total: monthlyMap.get(index) || 0,
        month_number: index + 1,
    }));

    const categories = Array.from(categoryMap.entries())
        .map(([name, value], index) => ({
            name,
            value,
            fill: CATEGORY_COLORS[index % CATEGORY_COLORS.length],
        }))
        .sort((a, b) => b.value - a.value);

    const districts = Array.from(districtMap.entries())
        .map(([name, total]) => ({
            name,
            total,
        }))
        .sort((a, b) => b.total - a.total);

    const allRecentReports = [...filteredReports]
        .sort((a, b) => {
            const dateA = new Date(getReportDate(a)).getTime();
            const dateB = new Date(getReportDate(b)).getTime();
            return dateB - dateA;
        })
        .map((item, index) => normalizeRecentReportItem(item, index, source));

    const recentReports = allRecentReports.slice(0, 6);
    const recentPoliceReports = allRecentReports.filter(isPoliceRecentReport).slice(0, 8);
    const recentCommunityReports = allRecentReports.filter(isCommunityRecentReport).slice(0, 8);

    const total = filteredReports.length;

    return {
        summary: {
            total,
            pending,
            approved,
            rejected,
            districts: districts.length,
            top_district: districts[0]?.name || '-',
            avg_per_month: total / 12,
        },
        monthly,
        categories,
        districts,
        recent_reports: recentReports,
        recent_police_reports: recentPoliceReports,
        recent_community_reports: recentCommunityReports,
        available_years: allYears.length ? allYears : [CURRENT_YEAR],
        updated_at: new Date().toISOString(),
        source,
    };
}


function buildIntegratedStatistics(mapReports: ReportRecord[], selectedYear: string): StatisticPayload {
    const policeReports: ReportRecord[] = dummyIncidents.map((item: any) => ({
        id: `police-${item.id}`,
        type: item.type,
        kategori: item.kategori,
        description: item.description,
        location: item.location,
        district: item.kecamatan,
        date: item.date,
        status: 'approved',
        source: 'police',
    }));

    const communityReports: ReportRecord[] = mapReports.map((item: any) => ({
        ...item,
        status: item.status || 'approved',
        source: item.source || 'community',
    }));

    const payload = buildStatisticsFromReports([...policeReports, ...communityReports], selectedYear, 'map-api');
    payload.available_years = Array.from(new Set(['2026', '2025', '2024', '2023', '2022', '2021', '2020', ...payload.available_years]))
        .sort((a, b) => Number(b) - Number(a));
    payload.source = 'database';

    return payload;
}

function buildDummyStatistics(selectedYear: string): StatisticPayload {
    const reports: ReportRecord[] = dummyIncidents.map((item: any) => ({
        id: item.id,
        type: item.type,
        kategori: item.kategori,
        description: item.description,
        location: item.location,
        district: item.kecamatan,
        date: item.date,
        status: item.status || 'approved',
        source: 'police',
    }));

    return buildStatisticsFromReports(reports, selectedYear, 'dummy');
}

async function fetchJson(url: string) {
    const response = await fetch(url, {
        method: 'GET',
        headers: {
            Accept: 'application/json',
            'X-Requested-With': 'XMLHttpRequest',
        },
    });

    if (!response.ok) {
        throw new Error(`Gagal memuat ${url}. Status ${response.status}`);
    }

    return response.json();
}

function riskLevel(total: number, max: number) {
    if (!max) return { label: 'Rendah', cls: 'border-slate-200 bg-slate-50 text-slate-600 dark:text-slate-200' };

    const pct = total / max;
    if (pct >= 0.66) return { label: 'Tinggi', cls: 'border-rose-200 bg-rose-50 text-rose-700' };
    if (pct >= 0.33) return { label: 'Sedang', cls: 'border-[#D8E4ED] bg-[#EFF4F8] text-[#D95F5F]' };
    return { label: 'Rendah', cls: 'border-[#D8E4ED] bg-[#EFF4F8] text-[#D95F5F]' };
}

function SourceBadge({ source }: { source: StatisticPayload['source'] }) {
    const config = {
        database: {
            label: 'Pelaporan Masyarakat',
            className: 'border-rose-200 bg-rose-50 text-rose-700',
        },
        'map-api': {
            label: 'Data Kejadian Kepolisian',
            className: 'border-slate-200 bg-slate-100 text-slate-700',
        },
        dummy: {
            label: 'Data Kepolisian Lokal',
            className: 'border-slate-200 bg-slate-100 text-slate-700',
        },
    }[source];

    return (
        <span className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-black ${config.className}`}>
            <Database className="h-3.5 w-3.5" />
            {config.label}
        </span>
    );
}

function MetricCard({
    title,
    value,
    description,
    icon: Icon,
    tone = 'teal',
}: {
    title: string;
    value: string | number;
    description: string;
    icon: any;
    tone?: 'teal' | 'blue' | 'amber' | 'rose';
}) {
    const toneClass = {
        teal: 'bg-[#EFF4F8] text-[#D95F5F] border-[#D8E4ED]',
        blue: 'bg-[#EFF4F8] text-[#D95F5F] border-[#D8E4ED]',
        amber: 'bg-[#EFF4F8] text-[#D95F5F] border-[#D8E4ED]',
        rose: 'bg-rose-50 text-rose-700 border-rose-100',
    }[tone];

    return (
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:bg-[#102538] dark:text-white transition hover:-translate-y-0.5 hover:shadow-md">
            <div className="flex items-start justify-between gap-3">
                <div>
                    <p className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-300">{title}</p>
                    <p className="mt-2 text-3xl font-black text-foreground">{value}</p>
                    <p className="mt-1 text-xs leading-relaxed text-slate-500 dark:text-slate-300">{description}</p>
                </div>
                <div className={`rounded-2xl border p-3 ${toneClass}`}>
                    <Icon className="h-5 w-5" />
                </div>
            </div>
        </div>
    );
}

function RecentDataTable({
    title,
    description,
    records,
    tone,
}: {
    title: string;
    description: string;
    records: RecentReport[];
    tone: 'police' | 'community';
}) {
    const iconClass = tone === 'community'
        ? 'bg-rose-50 text-rose-700 border-rose-200'
        : 'bg-slate-100 text-slate-700 border-slate-200';

    return (
        <section className="jaga-statistics-card rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                    <h2 className="flex items-center gap-2 text-lg font-black text-[#0F1F2E]">
                        <span className={`flex h-9 w-9 items-center justify-center rounded-2xl border ${iconClass}`}>
                            {tone === 'community' ? <FileWarning className="h-4 w-4" /> : <ShieldAlert className="h-4 w-4" />}
                        </span>
                        {title}
                    </h2>
                    <p className="mt-1 text-xs font-semibold text-slate-500">{description}</p>
                </div>
            </div>

            <div className="overflow-hidden rounded-2xl border border-slate-200">
                <div className="overflow-x-auto">
                    <table className="w-full min-w-[620px] text-left text-sm">
                        <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                            <tr>
                                <th className="px-4 py-3">Kode</th>
                                <th className="px-4 py-3">Jenis</th>
                                <th className="px-4 py-3">Lokasi</th>
                                <th className="px-4 py-3">Tanggal</th>
                                <th className="px-4 py-3">Status</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {records.length ? records.map((item, index) => (
                                <tr key={`${item.report_code}-${index}`} className="bg-white transition hover:bg-slate-50">
                                    <td className="px-4 py-3 font-black text-slate-800">{item.report_code || '-'}</td>
                                    <td className="px-4 py-3">
                                        <span className="line-clamp-2 text-xs font-semibold text-slate-700">{item.type || item.title || '-'}</span>
                                    </td>
                                    <td className="px-4 py-3 text-xs text-slate-600">
                                        <div className="font-black text-slate-800">{item.district || '-'}</div>
                                        <div>{item.village || '-'}</div>
                                    </td>
                                    <td className="px-4 py-3 text-xs font-semibold text-slate-600">{formatDate(item.date)}</td>
                                    <td className="px-4 py-3">
                                        <span className={`inline-flex rounded-full border px-2.5 py-1 text-[11px] font-black ${statusClass(item.status)}`}>
                                            {statusLabel(item.status)}
                                        </span>
                                    </td>
                                </tr>
                            )) : (
                                <tr>
                                    <td colSpan={5} className="px-4 py-10 text-center text-sm text-slate-500">
                                        Belum ada data pada kategori ini untuk periode terpilih.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
    );
}

export default function Statistics() {
    const [selectedYear, setSelectedYear] = useState(CURRENT_YEAR);
    const [data, setData] = useState<StatisticPayload>(() => buildDummyStatistics(CURRENT_YEAR));
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [showAllDistricts, setShowAllDistricts] = useState(false);
    const [lookupEmail, setLookupEmail] = useState('');
    const [lookupCode, setLookupCode] = useState('');
    const [lookupLoading, setLookupLoading] = useState(false);
    const [lookupError, setLookupError] = useState<string | null>(null);
    const [lookupResults, setLookupResults] = useState<StatusLookupResult[]>([]);

    const loadStatistics = async (year: string) => {
        setLoading(true);
        setError(null);

        try {
            const payload = await fetchJson(`/api/statistics?year=${encodeURIComponent(year)}`);
            const normalized = normalizeApiStatistics(payload, year);

            if (normalized) {
                setData(normalized);
                return;
            }

            throw new Error('Format response /api/statistics belum sesuai.');
        } catch (statisticsError: any) {
            try {
                const mapPayload = await fetchJson('/api/map/incidents');
                const reports = extractReports(mapPayload);
                setData(buildIntegratedStatistics(reports, year));
                setError(null);
            } catch (mapError) {
                console.error(statisticsError, mapError);
                setData(buildDummyStatistics(year));
                setError(null);
            }
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadStatistics(selectedYear);
    }, [selectedYear]);

    const yearOptions = useMemo(() => {
        const years = new Set<string>(['2026', '2025', '2024', '2023', '2022', '2021', '2020', ...data.available_years]);
        return Array.from(years).sort((a, b) => Number(b) - Number(a));
    }, [data.available_years]);

    const maxDistrict = useMemo(() => Math.max(0, ...data.districts.map((item) => item.total)), [data.districts]);
    const shownDistricts = showAllDistricts ? data.districts : data.districts.slice(0, 7);
    const recentPoliceReports = data.recent_police_reports?.length
        ? data.recent_police_reports
        : data.recent_reports.filter(isPoliceRecentReport);
    const recentCommunityReports = data.recent_community_reports?.length
        ? data.recent_community_reports
        : data.recent_reports.filter(isCommunityRecentReport);

    const verifiedPercentage = data.summary.total
        ? Math.round((data.summary.approved / data.summary.total) * 100)
        : 0;

    const downloadableCsv = useMemo(() => {
        const rows = [
            ['Kecamatan', 'Jumlah'],
            ...data.districts.map((item) => [item.name, String(item.total)]),
        ];
        return rows.map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(',')).join('\n');
    }, [data.districts]);

    const downloadCsv = () => {
        const blob = new Blob([downloadableCsv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.download = `statistik-kejadian-${selectedYear}.csv`;
        document.body.appendChild(anchor);
        anchor.click();
        document.body.removeChild(anchor);
        URL.revokeObjectURL(url);
    };

    const submitStatusLookup = async (event: FormEvent<HTMLFormElement>) => {
        event.preventDefault();

        const email = lookupEmail.trim();
        const code = lookupCode.trim();

        setLookupError(null);
        setLookupResults([]);

        if (!email) {
            setLookupError('Email pelapor wajib diisi.');
            return;
        }

        setLookupLoading(true);

        try {
            const params = new URLSearchParams();
            params.set('reporter_email', email);

            if (code) {
                params.set('report_code', code);
            }

            const payload = await fetchJson(`/api/incident-reports/status?${params.toString()}`);
            setLookupResults(Array.isArray(payload?.data) ? payload.data : []);
        } catch (lookupErrorValue: any) {
            setLookupError(
                lookupErrorValue?.message?.includes('404')
                    ? 'Status laporan tidak ditemukan. Pastikan email dan kode laporan sesuai.'
                    : 'Status laporan belum berhasil dimuat. Coba lagi atau periksa email/kode laporan.',
            );
        } finally {
            setLookupLoading(false);
        }
    };

    return (
        <div className="min-h-screen theme-shell">
            <section className="jaga-statistics-hero relative overflow-hidden border-b border-slate-200 bg-[#F8FAFC] px-4 py-10 text-[#0F1F2E] md:px-8">
                <div className="pointer-events-none absolute inset-0 opacity-80">
                    <div className="absolute -left-28 -top-28 h-80 w-80 rounded-full bg-slate-200/70 blur-3xl" />
                    <div className="absolute right-0 top-0 h-80 w-80 rounded-full bg-rose-100/70 blur-3xl" />
                </div>

                <div className="relative mx-auto max-w-6xl">
                    <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
                        <div className="max-w-4xl">
                            <div className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-black text-slate-700 shadow-sm">
                                <BarChart3 className="h-4 w-4 text-[#334155]" />
                                Dashboard Statistik Laporan
                            </div>

                            <h1 className="mt-5 text-4xl font-black tracking-tight text-[#0F1F2E] md:text-6xl">
                                Statistik Kejadian JagaSleman
                            </h1>

                            <p className="mt-4 max-w-4xl text-base font-semibold leading-relaxed text-slate-600 md:text-lg">
                                Ringkasan laporan masyarakat dan data kejadian kepolisian tahun 2020–2026 divisualisasikan dalam grafik bulanan,
                                kategori kejadian, wilayah rawan, serta status laporan terbaru secara terpadu.
                            </p>
                        </div>

                        <div className="flex flex-wrap items-center gap-2">
                            <SourceBadge source={data.source} />
                            <button
                                type="button"
                                onClick={() => loadStatistics(selectedYear)}
                                className="inline-flex items-center gap-2 rounded-full border border-[#334155] bg-[#334155] px-4 py-2 text-sm font-black text-white shadow-sm transition hover:bg-[#1F2937]"
                            >
                                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCcw className="h-4 w-4" />}
                                Refresh
                            </button>
                        </div>
                    </div>
                </div>
            </section>

            <main className="mx-auto max-w-6xl space-y-6 px-4 py-6 md:px-8">
                <section className="jaga-statistics-card -mt-10 rounded-3xl border border-slate-200 bg-white p-4 shadow-xl shadow-[#0F1F2E]/10 md:p-5">
                    <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                        <div>
                            <p className="text-xs font-black uppercase tracking-[0.18em] text-slate-500">Filter tahun</p>
                            <div className="mt-2 flex flex-wrap gap-2">
                                {yearOptions.map((year) => (
                                    <button
                                        key={year}
                                        type="button"
                                        onClick={() => setSelectedYear(year)}
                                        className={`rounded-full border px-4 py-2 text-xs font-black transition ${
                                            selectedYear === year
                                                ? 'border-[#334155] bg-[#334155] text-white shadow-md'
                                                : 'border-slate-300 bg-white text-slate-800 hover:bg-slate-100'
                                        }`}
                                    >
                                        {year}
                                    </button>
                                ))}

                                <button
                                    type="button"
                                    onClick={() => setSelectedYear('all')}
                                    className={`rounded-full border px-4 py-2 text-xs font-black transition ${
                                        selectedYear === 'all'
                                            ? 'border-[#334155] bg-[#334155] text-white shadow-md'
                                            : 'border-slate-300 bg-white text-slate-800 hover:bg-slate-100'
                                    }`}
                                >
                                    Semua
                                </button>
                            </div>
                        </div>

                        <div className="flex flex-wrap items-center gap-2">
                            <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-xs text-slate-600">
                                <div className="flex items-center gap-2 font-black text-[#0F1F2E]">
                                    <CalendarDays className="h-4 w-4 text-[#334155]" />
                                    Update data
                                </div>
                                <p className="mt-1 font-semibold">{formatDate(data.updated_at || new Date().toISOString())}</p>
                            </div>

                            <button
                                type="button"
                                onClick={downloadCsv}
                                className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-xs font-black text-slate-700 shadow-sm transition hover:bg-slate-50"
                            >
                                <Download className="h-4 w-4" />
                                Export CSV
                            </button>
                        </div>
                    </div>

                    {error && (
                        <div className="mt-4 flex gap-3 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm font-semibold text-amber-800">
                            <AlertCircle className="mt-0.5 h-5 w-5 flex-shrink-0" />
                            <p>{error}</p>
                        </div>
                    )}
                </section>

                <section className="grid gap-4 md:grid-cols-2">
                    <div className="jaga-statistics-card rounded-[1.5rem] border border-slate-200 bg-white p-5 text-[#0F1F2E] shadow-sm">
                        <div className="flex items-start gap-4">
                            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-slate-100 text-[#334155]">
                                <ShieldAlert className="h-6 w-6" />
                            </div>
                            <div>
                                <h3 className="text-lg font-black text-[#0F1F2E]">Data Kejadian Kepolisian</h3>
                                <p className="mt-2 text-sm font-semibold leading-relaxed text-slate-600">
                                    Data yang berasal dari GeoJSON atau data kepolisian Polresta/Polsek Sleman ditampilkan sebagai
                                    <strong> data kejadian</strong>, bukan sebagai pelaporan masyarakat.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div className="jaga-statistics-card rounded-[1.5rem] border border-rose-200 bg-rose-50 p-5 text-[#0F1F2E] shadow-sm">
                        <div className="flex items-start gap-4">
                            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-rose-100 text-rose-700">
                                <FileWarning className="h-6 w-6" />
                            </div>
                            <div>
                                <h3 className="text-lg font-black text-[#0F1F2E]">Pelaporan Masyarakat</h3>
                                <p className="mt-2 text-sm font-semibold leading-relaxed text-slate-600">
                                    Data yang masuk melalui formulir <strong>Buat Laporan</strong> disebut pelaporan. Status laporan dapat dicek
                                    menggunakan email dan kode laporan.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div className="jaga-statistics-card rounded-[1.25rem] border border-slate-200 bg-white p-4 text-sm font-bold text-slate-600 shadow-sm md:col-span-2">
                        Sumber aktif saat ini:
                        <span className="ml-2 inline-flex rounded-full bg-slate-100 px-3 py-1 font-black text-[#0F1F2E]">
                            {getDataSourceLabel(data.source)}
                        </span>
                        <span className="mt-2 block font-semibold text-slate-500">
                            {getDataSourceDescription(data.source)}
                        </span>
                    </div>
                </section>

                <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                    <div className="flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
                        <div className="max-w-2xl">
                            <div className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-slate-100 px-3 py-1 text-xs font-black uppercase tracking-[0.18em] text-slate-700">
                                <Mail className="h-3.5 w-3.5" />
                                Cek Status Laporan
                            </div>

                            <h2 className="mt-3 text-xl font-black text-[#0F1F2E]">Pantau status pelaporan masyarakat.</h2>
                            <p className="mt-2 text-sm font-semibold leading-6 text-slate-600">
                                Masukkan email pelapor dan kode laporan untuk melihat status terbaru. Data ini khusus untuk laporan yang dikirim masyarakat.
                            </p>
                        </div>

                        <form onSubmit={submitStatusLookup} className="w-full max-w-xl rounded-2xl border border-slate-200 bg-slate-50 p-4">
                            <div className="grid gap-3 sm:grid-cols-[1fr_0.8fr_auto]">
                                <input
                                    type="email"
                                    value={lookupEmail}
                                    onChange={(event) => setLookupEmail(event.target.value)}
                                    placeholder="Email pelapor"
                                    className="h-11 rounded-xl border border-slate-300 bg-white px-4 text-sm font-semibold text-slate-800 outline-none focus:border-[#334155]"
                                />
                                <input
                                    value={lookupCode}
                                    onChange={(event) => setLookupCode(event.target.value)}
                                    placeholder="Kode laporan"
                                    className="h-11 rounded-xl border border-slate-300 bg-white px-4 text-sm font-semibold text-slate-800 outline-none focus:border-[#334155]"
                                />
                                <button
                                    type="submit"
                                    disabled={lookupLoading}
                                    className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-[#334155] px-5 text-sm font-black text-white transition hover:bg-[#1F2937] disabled:cursor-not-allowed disabled:bg-slate-300"
                                >
                                    {lookupLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                                    Cek
                                </button>
                            </div>

                            {lookupError && (
                                <div className="mt-3 flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-semibold text-rose-700">
                                    <XCircle className="mt-0.5 h-4 w-4 flex-shrink-0" />
                                    <p>{lookupError}</p>
                                </div>
                            )}

                            {lookupResults.length > 0 && (
                                <div className="mt-3 space-y-2">
                                    {lookupResults.map((item) => (
                                        <div key={`${item.id}-${item.report_code}`} className="rounded-xl border border-slate-200 bg-white p-3 text-xs">
                                            <div className="flex flex-wrap items-center justify-between gap-2">
                                                <span className="font-black text-[#0F1F2E]">{item.report_code || '-'}</span>
                                                <span className={`rounded-full border px-2.5 py-1 font-black ${statusClass(item.status)}`}>
                                                    {item.status_label || statusLabel(item.status)}
                                                </span>
                                            </div>
                                            <p className="mt-2 font-semibold text-slate-700">{item.incident_type || item.title || 'Laporan kejadian'}</p>
                                            <p className="mt-1 text-slate-500">{item.location || item.district || '-'}</p>
                                            {item.rejection_reason && (
                                                <p className="mt-2 rounded-lg bg-rose-50 p-2 font-semibold text-rose-700">
                                                    Alasan penolakan: {item.rejection_reason}
                                                </p>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            )}
                        </form>
                    </div>
                </section>

                <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                    <MetricCard
                        title="Total Data"
                        value={numberFormat(data.summary.total)}
                        description={`Gabungan data pada tahun ${selectedYear === 'all' ? 'semua periode' : selectedYear}.`}
                        icon={Database}
                        tone="blue"
                    />
                    <MetricCard
                        title="Terverifikasi"
                        value={numberFormat(data.summary.approved)}
                        description={`${verifiedPercentage}% data sudah berstatus terverifikasi.`}
                        icon={CheckCircle2}
                        tone="teal"
                    />
                    <MetricCard
                        title="Menunggu"
                        value={numberFormat(data.summary.pending)}
                        description="Laporan masyarakat yang masih perlu validasi."
                        icon={Clock3}
                        tone="amber"
                    />
                    <MetricCard
                        title="Ditolak"
                        value={numberFormat(data.summary.rejected)}
                        description="Laporan masyarakat yang tidak lolos validasi."
                        icon={XCircle}
                        tone="rose"
                    />
                </section>

                <div className="grid gap-6 xl:grid-cols-[1.25fr_0.75fr]">
                    <section className="jaga-statistics-card rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                        <div className="mb-4 flex items-start justify-between gap-3">
                            <div>
                                <h2 className="flex items-center gap-2 text-lg font-black text-[#0F1F2E]">
                                    <TrendingUp className="h-5 w-5 text-[#334155]" />
                                    Tren Bulanan
                                </h2>
                                <p className="mt-1 text-xs font-semibold text-slate-500">Jumlah data per bulan pada periode terpilih.</p>
                            </div>
                        </div>

                        <div className="h-80 min-h-[320px] min-w-0">
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={data.monthly} margin={{ top: 16, right: 10, left: -15, bottom: 0 }}>
                                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                    <XAxis dataKey="month" tickLine={false} axisLine={false} />
                                    <YAxis allowDecimals={false} tickLine={false} axisLine={false} />
                                    <Tooltip />
                                    <Bar dataKey="total" radius={[10, 10, 0, 0]} fill="#334155" />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </section>

                    <section className="jaga-statistics-card rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                        <div className="mb-4">
                            <h2 className="flex items-center gap-2 text-lg font-black text-[#0F1F2E]">
                                <Activity className="h-5 w-5 text-[#334155]" />
                                Kategori Kejadian
                            </h2>
                            <p className="mt-1 text-xs font-semibold text-slate-500">Komposisi jenis kejadian yang tercatat.</p>
                        </div>

                        {data.categories.length ? (
                            <>
                                <div className="h-64 min-h-[260px] min-w-0">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <PieChart>
                                            <Pie
                                                data={data.categories}
                                                dataKey="value"
                                                nameKey="name"
                                                innerRadius={54}
                                                outerRadius={86}
                                                paddingAngle={3}
                                            >
                                                {data.categories.map((item, index) => (
                                                    <Cell key={item.name} fill={item.fill || CATEGORY_COLORS[index % CATEGORY_COLORS.length]} />
                                                ))}
                                            </Pie>
                                            <Tooltip />
                                        </PieChart>
                                    </ResponsiveContainer>
                                </div>

                                <div className="mt-3 space-y-2">
                                    {data.categories.slice(0, 6).map((item, index) => (
                                        <div key={item.name} className="flex items-center justify-between gap-3 rounded-2xl bg-slate-50 px-3 py-2">
                                            <div className="flex min-w-0 items-center gap-2">
                                                <span className="h-3 w-3 flex-shrink-0 rounded-full" style={{ backgroundColor: item.fill || CATEGORY_COLORS[index % CATEGORY_COLORS.length] }} />
                                                <span className="truncate text-xs font-black text-slate-700">{item.name}</span>
                                            </div>
                                            <span className="text-xs font-black text-[#0F1F2E]">{item.value}</span>
                                        </div>
                                    ))}
                                </div>
                            </>
                        ) : (
                            <div className="flex h-64 flex-col items-center justify-center rounded-2xl border border-dashed border-slate-300 bg-slate-50 text-center text-slate-500">
                                <FileWarning className="mb-2 h-8 w-8" />
                                <p className="text-sm font-semibold">Belum ada data kategori.</p>
                            </div>
                        )}
                    </section>
                </div>

                <div className="grid gap-6 lg:grid-cols-[0.95fr_1.05fr]">
                    <section className="jaga-statistics-card rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                        <div className="mb-4 flex items-start justify-between gap-3">
                            <div>
                                <h2 className="flex items-center gap-2 text-lg font-black text-[#0F1F2E]">
                                    <MapPin className="h-5 w-5 text-[#334155]" />
                                    Kecamatan Rawan
                                </h2>
                                <p className="mt-1 text-xs font-semibold text-slate-500">Ranking wilayah berdasarkan jumlah kejadian.</p>
                            </div>
                            <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-black text-slate-700">
                                Top: {data.summary.top_district}
                            </span>
                        </div>

                        <div className="space-y-3">
                            {shownDistricts.length ? shownDistricts.map((item, index) => {
                                const width = maxDistrict ? Math.max(8, Math.round((item.total / maxDistrict) * 100)) : 0;
                                const risk = riskLevel(item.total, maxDistrict);

                                return (
                                    <div key={item.name} className="rounded-2xl border border-slate-100 bg-slate-50 p-3">
                                        <div className="mb-2 flex items-center justify-between gap-3">
                                            <div className="flex min-w-0 items-center gap-2">
                                                <span className={`flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full text-xs font-black ${
                                                    index === 0 ? 'bg-rose-100 text-rose-700' :
                                                    index === 1 ? 'bg-amber-100 text-amber-700' :
                                                    index === 2 ? 'bg-yellow-100 text-yellow-700' :
                                                    'bg-white text-slate-600'
                                                }`}>
                                                    {index + 1}
                                                </span>
                                                <span className="truncate text-sm font-black text-slate-800">{item.name}</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <span className={`rounded-full border px-2.5 py-1 text-[11px] font-black ${risk.cls}`}>{risk.label}</span>
                                                <span className="text-sm font-black text-[#0F1F2E]">{item.total}</span>
                                            </div>
                                        </div>
                                        <div className="h-2 overflow-hidden rounded-full bg-white">
                                            <div className="h-full rounded-full bg-[#334155]" style={{ width: `${width}%` }} />
                                        </div>
                                    </div>
                                );
                            }) : (
                                <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-8 text-center text-sm text-slate-500">
                                    Belum ada data kecamatan untuk periode ini.
                                </div>
                            )}
                        </div>

                        {data.districts.length > 7 && (
                            <button
                                type="button"
                                onClick={() => setShowAllDistricts((value) => !value)}
                                className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-xs font-black text-slate-700 transition hover:bg-slate-50"
                            >
                                {showAllDistricts ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                                {showAllDistricts ? 'Sembunyikan' : `Tampilkan semua ${data.districts.length} kecamatan`}
                            </button>
                        )}
                    </section>

                    <div className="grid gap-6 xl:grid-cols-2">
                        <RecentDataTable
                            title="Data Kepolisian"
                            description="Hanya menampilkan data kejadian kepolisian, bukan pelaporan masyarakat."
                            records={recentPoliceReports}
                            tone="police"
                        />

                        <RecentDataTable
                            title="Laporan Masyarakat"
                            description="Hanya menampilkan laporan yang dikirim masyarakat melalui formulir."
                            records={recentCommunityReports}
                            tone="community"
                        />
                    </div>
                </div>

                <section className="jaga-statistics-cta rounded-3xl border border-slate-200 bg-white p-6 text-[#0F1F2E] shadow-sm md:p-8">
                    <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
                        <div>
                            <div className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-slate-100 px-3 py-1.5 text-xs font-black text-slate-700">
                                <MapIcon className="h-4 w-4" />
                                Analisis Spasial
                            </div>
                            <h2 className="mt-4 text-2xl font-black text-[#0F1F2E]">Lihat pola kejadian secara spasial</h2>
                            <p className="mt-2 max-w-3xl text-sm font-semibold leading-relaxed text-slate-600">
                                Buka peta untuk membaca persebaran titik kejadian, wilayah rawan, batas kecamatan, serta visualisasi hotspot KDE.
                            </p>
                        </div>
                        <div className="flex flex-wrap gap-3">
                            <a
                                href="/webgis"
                                className="inline-flex items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-5 py-3 text-sm font-black text-[#0F1F2E] shadow-sm transition hover:bg-slate-50"
                            >
                                <MapIcon className="h-4 w-4" />
                                Lihat Peta
                            </a>
                            <a
                                href="/report"
                                className="inline-flex items-center justify-center gap-2 rounded-2xl border border-[#334155] bg-[#334155] px-5 py-3 text-sm font-black text-white shadow-sm transition hover:bg-[#1F2937]"
                            >
                                <FileWarning className="h-4 w-4" />
                                Buat Laporan
                            </a>
                        </div>
                    </div>
                </section>
            </main>
        </div>
    );
}
